export declare const ACTIVITY_SOURCE: {
    readonly GITHUB_USER: "GITHUB_USER";
    readonly HUBSPOT: "HUBSPOT";
    readonly HUBSPOT_USER: "HUBSPOT_USER";
    readonly DEPRECATED_AUTO_UNDEPLOY: "DEPRECATED_AUTO_UNDEPLOY";
};
