"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DEPLOY_ACTION = exports.DEPLOY_STATUS = void 0;
exports.DEPLOY_STATUS = {
    DEPLOYING: 'DEPLOYING',
    FAILURE: 'FAILURE',
    PENDING: 'PENDING',
    SUCCESS: 'SUCCESS',
    FINISHED: 'FINISHED',
};
exports.DEPLOY_ACTION = {
    REMOVE: 'REMOVE',
    INSTALL: 'INSTALL',
};
