export declare const BUILD_STATUS: {
    readonly BUILDING: "BUILDING";
    readonly FAILURE: "FAILURE";
    readonly PREPARING: "PREPARING";
    readonly PENDING: "PENDING";
    readonly SUCCESS: "SUCCESS";
};
export declare const SUBBUILD_TYPES: {
    readonly APP: "APP";
    readonly PRIVATE_APP: "PRIVATE_APP";
    readonly THEME: "THEME";
    readonly REACT_THEME: "REACT_THEME";
    readonly NO_SUBBUILDS: "NO_SUBBUILDS";
};
export declare const DEPLOYABLE_STATES: {
    DEPLOYABLE: string;
    DEPRECATED: string;
};
export declare const COMPONENT_TYPES: {
    readonly APP: "APP";
    readonly PRIVATE_APP: "PRIVATE_APP";
    readonly THEME: "THEME";
    readonly REACT_THEME: "REACT_THEME";
};
export declare const SUBCOMPONENT_TYPES: {
    readonly APP_ID: "APP_ID";
    readonly PACKAGE_LOCK_FILE: "PACKAGE_LOCK_FILE";
    readonly CRM_CARD_V2: "CRM_CARD_V2";
    readonly CARD_V2: "CARD_V2";
    readonly SERVERLESS_PKG: "SERVERLESS_PKG";
    readonly SERVERLESS_ROUTE: "SERVERLESS_ROUTE";
    readonly SERVERLESS_FUNCTION: "SERVERLESS_FUNCTION";
    readonly APP_FUNCTION: "APP_FUNCTION";
    readonly AUTOMATION_ACTION: "AUTOMATION_ACTION";
    readonly REACT_EXTENSION: "REACT_EXTENSION";
};
