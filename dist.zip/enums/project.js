"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ACTIVITY_SOURCE = void 0;
exports.ACTIVITY_SOURCE = {
    GITHUB_USER: 'GITHUB_USER',
    HUBSPOT: 'HUBSPOT',
    HUBSPOT_USER: 'HUBSPOT_USER',
    DEPRECATED_AUTO_UNDEPLOY: 'DEPRECATED_AUTO_UNDEPLOY',
};
