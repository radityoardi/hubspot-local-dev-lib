export declare const DEPLOY_STATUS: {
    readonly DEPLOYING: "DEPLOYING";
    readonly FAILURE: "FAILURE";
    readonly PENDING: "PENDING";
    readonly SUCCESS: "SUCCESS";
    readonly FINISHED: "FINISHED";
};
export declare const DEPLOY_ACTION: {
    REMOVE: string;
    INSTALL: string;
};
