"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getBuildStatus = exports.buildPackage = exports.getLatestFunctionLog = exports.getFunctionLogs = exports.getRoutes = void 0;
const http_1 = require("../http");
const FUNCTION_API_PATH = 'cms/v3/functions';
function getRoutes(accountId) {
    return http_1.http.get(accountId, {
        url: `${FUNCTION_API_PATH}/routes`,
    });
}
exports.getRoutes = getRoutes;
function getFunctionLogs(accountId, route, params = {}) {
    const { limit = 5 } = params;
    return http_1.http.get(accountId, {
        url: `${FUNCTION_API_PATH}/results/by-route/${encodeURIComponent(route)}`,
        params: { ...params, limit },
    });
}
exports.getFunctionLogs = getFunctionLogs;
function getLatestFunctionLog(accountId, route) {
    return http_1.http.get(accountId, {
        url: `${FUNCTION_API_PATH}/results/by-route/${encodeURIComponent(route)}/latest`,
    });
}
exports.getLatestFunctionLog = getLatestFunctionLog;
function buildPackage(accountId, folderPath) {
    return http_1.http.post(accountId, {
        url: `${FUNCTION_API_PATH}/build/async`,
        headers: {
            Accept: 'text/plain',
        },
        data: {
            folderPath,
        },
    });
}
exports.buildPackage = buildPackage;
function getBuildStatus(accountId, buildId) {
    return http_1.http.get(accountId, {
        url: `${FUNCTION_API_PATH}/build/${buildId}/poll`,
    });
}
exports.getBuildStatus = getBuildStatus;
