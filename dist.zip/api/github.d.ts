/// <reference types="node" />
/// <reference types="node" />
import { AxiosPromise } from 'axios';
import { GithubReleaseData, GithubRepoFile, RepoPath } from '../types/Github';
declare global {
    var githubToken: string;
}
export declare function fetchRepoReleaseData(repoPath: RepoPath, tag?: string): AxiosPromise<GithubReleaseData>;
export declare function fetchRepoAsZip(zipUrl: string): AxiosPromise<Buffer>;
export declare function fetchRepoFile(repoPath: RepoPath, filePath: string, ref: string): AxiosPromise<Buffer>;
export declare function fetchRepoFileByDownloadUrl(downloadUrl: string): AxiosPromise<Buffer>;
export declare function fetchRepoContents(repoPath: RepoPath, path: string, ref?: string): AxiosPromise<Array<GithubRepoFile>>;
