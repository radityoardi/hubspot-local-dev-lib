import { AxiosPromise } from 'axios';
import { Validation, HublValidationOptions } from '../types/HublValidation';
export declare function validateHubl(accountId: number, sourceCode: string, hublValidationOptions?: HublValidationOptions): AxiosPromise<Validation>;
