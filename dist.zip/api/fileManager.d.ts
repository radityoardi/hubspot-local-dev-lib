import { AxiosPromise } from 'axios';
import { FetchStatResponse, FetchFilesResponse, FetchFolderResponse, UploadResponse } from '../types/FileManager';
export declare function uploadFile(accountId: number, src: string, dest: string): AxiosPromise<UploadResponse>;
export declare function fetchStat(accountId: number, src: string): AxiosPromise<FetchStatResponse>;
export declare function fetchFiles(accountId: number, folderId: number | 'None', offset: number, archived?: boolean): AxiosPromise<FetchFilesResponse>;
export declare function fetchFolders(accountId: number, folderId: number | 'None'): AxiosPromise<FetchFolderResponse>;
