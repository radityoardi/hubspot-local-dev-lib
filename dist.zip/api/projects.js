"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.downloadClonedProject = exports.checkCloneStatus = exports.cloneApp = exports.checkMigrationStatus = exports.migrateApp = exports.fetchDeployWarnLogs = exports.fetchBuildWarnLogs = exports.cancelStagedBuild = exports.deleteFileFromBuild = exports.uploadFileToBuild = exports.queueBuild = exports.provisionBuild = exports.fetchProjectSettings = exports.getDeployStructure = exports.getDeployStatus = exports.deployProject = exports.getBuildStructure = exports.getBuildStatus = exports.fetchProjectBuilds = exports.fetchPlatformVersions = exports.deleteProject = exports.downloadProject = exports.fetchProjectComponentsMetadata = exports.fetchProject = exports.uploadProject = exports.createProject = exports.fetchProjects = void 0;
const http_1 = require("../http");
const fs_1 = __importDefault(require("fs"));
const PROJECTS_API_PATH = 'dfs/v1/projects';
const DEVELOPER_FILE_SYSTEM_PATH = 'dfs/v1';
const PROJECTS_DEPLOY_API_PATH = 'dfs/deploy/v1';
const PROJECTS_LOGS_API_PATH = 'dfs/logging/v1';
const DEVELOPER_PROJECTS_API_PATH = 'developer/projects/v1';
const MIGRATIONS_API_PATH = 'dfs/migrations/v1';
function fetchProjects(accountId) {
    return http_1.http.get(accountId, {
        url: DEVELOPER_PROJECTS_API_PATH,
    });
}
exports.fetchProjects = fetchProjects;
function createProject(accountId, name) {
    return http_1.http.post(accountId, {
        url: DEVELOPER_PROJECTS_API_PATH,
        data: {
            name,
        },
    });
}
exports.createProject = createProject;
function uploadProject(accountId, projectName, projectFile, uploadMessage, platformVersion) {
    const formData = {
        file: fs_1.default.createReadStream(projectFile),
        uploadMessage,
    };
    if (platformVersion) {
        formData.platformVersion = platformVersion;
    }
    return http_1.http.post(accountId, {
        url: `${PROJECTS_API_PATH}/upload/${encodeURIComponent(projectName)}`,
        timeout: 60_000,
        data: formData,
        headers: { 'Content-Type': 'multipart/form-data' },
    });
}
exports.uploadProject = uploadProject;
function fetchProject(accountId, projectName) {
    return http_1.http.get(accountId, {
        url: `${DEVELOPER_PROJECTS_API_PATH}/by-name/${encodeURIComponent(projectName)}`,
    });
}
exports.fetchProject = fetchProject;
async function fetchProjectComponentsMetadata(accountId, projectId) {
    return http_1.http.get(accountId, {
        url: `${DEVELOPER_FILE_SYSTEM_PATH}/projects-deployed-build/${projectId}`,
    });
}
exports.fetchProjectComponentsMetadata = fetchProjectComponentsMetadata;
async function downloadProject(accountId, projectName, buildId) {
    return http_1.http.get(accountId, {
        url: `${PROJECTS_API_PATH}/${encodeURIComponent(projectName)}/builds/${buildId}/archive-full`,
        responseType: 'arraybuffer',
        headers: { accept: 'application/zip', 'Content-Type': 'application/json' },
    });
}
exports.downloadProject = downloadProject;
function deleteProject(accountId, projectName) {
    return http_1.http.delete(accountId, {
        url: `${DEVELOPER_PROJECTS_API_PATH}/${encodeURIComponent(projectName)}`,
    });
}
exports.deleteProject = deleteProject;
function fetchPlatformVersions(accountId) {
    return http_1.http.get(accountId, {
        url: `${DEVELOPER_PROJECTS_API_PATH}/platformVersion`,
    });
}
exports.fetchPlatformVersions = fetchPlatformVersions;
function fetchProjectBuilds(accountId, projectName, params = {}) {
    return http_1.http.get(accountId, {
        url: `${PROJECTS_API_PATH}/${encodeURIComponent(projectName)}/builds`,
        params,
    });
}
exports.fetchProjectBuilds = fetchProjectBuilds;
function getBuildStatus(accountId, projectName, buildId) {
    return http_1.http.get(accountId, {
        url: `${PROJECTS_API_PATH}/${encodeURIComponent(projectName)}/builds/${buildId}/status`,
    });
}
exports.getBuildStatus = getBuildStatus;
function getBuildStructure(accountId, projectName, buildId) {
    return http_1.http.get(accountId, {
        url: `dfs/v1/builds/by-project-name/${encodeURIComponent(projectName)}/builds/${buildId}/structure`,
    });
}
exports.getBuildStructure = getBuildStructure;
function deployProject(accountId, projectName, buildId) {
    return http_1.http.post(accountId, {
        url: `${PROJECTS_DEPLOY_API_PATH}/deploys/queue/async`,
        data: {
            projectName,
            buildId,
        },
    });
}
exports.deployProject = deployProject;
function getDeployStatus(accountId, projectName, deployId) {
    return http_1.http.get(accountId, {
        url: `${PROJECTS_DEPLOY_API_PATH}/deploy-status/projects/${encodeURIComponent(projectName)}/deploys/${deployId}`,
    });
}
exports.getDeployStatus = getDeployStatus;
function getDeployStructure(accountId, projectName, deployId) {
    return http_1.http.get(accountId, {
        url: `${PROJECTS_DEPLOY_API_PATH}/deploys/by-project-name/${encodeURIComponent(projectName)}/deploys/${deployId}/structure`,
    });
}
exports.getDeployStructure = getDeployStructure;
function fetchProjectSettings(accountId, projectName) {
    return http_1.http.get(accountId, {
        url: `${DEVELOPER_PROJECTS_API_PATH}/${encodeURIComponent(projectName)}/settings`,
    });
}
exports.fetchProjectSettings = fetchProjectSettings;
async function provisionBuild(accountId, projectName, platformVersion) {
    return http_1.http.post(accountId, {
        url: `${PROJECTS_API_PATH}/${encodeURIComponent(projectName)}/builds/staged/provision`,
        params: { platformVersion },
        headers: { 'Content-Type': 'application/json' },
        timeout: 50_000,
    });
}
exports.provisionBuild = provisionBuild;
function queueBuild(accountId, projectName, platformVersion) {
    return http_1.http.post(accountId, {
        url: `${PROJECTS_API_PATH}/${encodeURIComponent(projectName)}/builds/staged/queue`,
        params: { platformVersion },
        headers: { 'Content-Type': 'application/json' },
    });
}
exports.queueBuild = queueBuild;
function uploadFileToBuild(accountId, projectName, filePath, path) {
    return http_1.http.put(accountId, {
        url: `${PROJECTS_API_PATH}/${encodeURIComponent(projectName)}/builds/staged/files/${encodeURIComponent(path)}`,
        data: {
            file: fs_1.default.createReadStream(filePath),
        },
        headers: { 'Content-Type': 'multipart/form-data' },
    });
}
exports.uploadFileToBuild = uploadFileToBuild;
function deleteFileFromBuild(accountId, projectName, path) {
    return http_1.http.delete(accountId, {
        url: `${PROJECTS_API_PATH}/${encodeURIComponent(projectName)}/builds/staged/files/${encodeURIComponent(path)}`,
    });
}
exports.deleteFileFromBuild = deleteFileFromBuild;
function cancelStagedBuild(accountId, projectName) {
    return http_1.http.post(accountId, {
        url: `${PROJECTS_API_PATH}/${encodeURIComponent(projectName)}/builds/staged/cancel`,
        headers: { 'Content-Type': 'application/json' },
    });
}
exports.cancelStagedBuild = cancelStagedBuild;
function fetchBuildWarnLogs(accountId, projectName, buildId) {
    return http_1.http.get(accountId, {
        url: `${PROJECTS_LOGS_API_PATH}/logs/projects/${encodeURIComponent(projectName)}/builds/${buildId}/combined/warn`,
    });
}
exports.fetchBuildWarnLogs = fetchBuildWarnLogs;
function fetchDeployWarnLogs(accountId, projectName, deployId) {
    return http_1.http.get(accountId, {
        url: `${PROJECTS_LOGS_API_PATH}/logs/projects/${encodeURIComponent(projectName)}/deploys/${deployId}/combined/warn`,
    });
}
exports.fetchDeployWarnLogs = fetchDeployWarnLogs;
function migrateApp(accountId, appId, projectName) {
    return http_1.http.post(accountId, {
        url: `${MIGRATIONS_API_PATH}/migrations`,
        data: {
            componentId: appId,
            componentType: 'PUBLIC_APP_ID',
            projectName,
        },
    });
}
exports.migrateApp = migrateApp;
function checkMigrationStatus(accountId, id) {
    return http_1.http.get(accountId, {
        url: `${MIGRATIONS_API_PATH}/migrations/${id}`,
    });
}
exports.checkMigrationStatus = checkMigrationStatus;
function cloneApp(accountId, appId) {
    return http_1.http.post(accountId, {
        url: `${MIGRATIONS_API_PATH}/exports`,
        data: {
            componentId: appId,
            componentType: 'PUBLIC_APP_ID',
        },
    });
}
exports.cloneApp = cloneApp;
function checkCloneStatus(accountId, exportId) {
    return http_1.http.get(accountId, {
        url: `${MIGRATIONS_API_PATH}/exports/${exportId}/status`,
    });
}
exports.checkCloneStatus = checkCloneStatus;
function downloadClonedProject(accountId, exportId) {
    return http_1.http.get(accountId, {
        url: `${MIGRATIONS_API_PATH}/exports/${exportId}/download-as-clone`,
        responseType: 'arraybuffer',
    });
}
exports.downloadClonedProject = downloadClonedProject;
