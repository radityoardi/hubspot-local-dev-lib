"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.fetchSandboxHubData = exports.getSandboxUsageLimits = exports.deleteSandbox = exports.createSandbox = void 0;
const axios_1 = __importDefault(require("axios"));
const http_1 = require("../http");
const getAxiosConfig_1 = require("../http/getAxiosConfig");
const environments_1 = require("../constants/environments");
const api_1 = require("../constants/api");
const SANDBOX_API_PATH = 'sandbox-hubs/v1';
const SANDBOX_API_PATH_V2 = 'sandbox-hubs/v2';
function createSandbox(accountId, name, type) {
    return http_1.http.post(accountId, {
        data: { name, type, generatePersonalAccessKey: true },
        timeout: api_1.SANDBOX_TIMEOUT,
        url: SANDBOX_API_PATH_V2, // Create uses v2 for sandbox type and PAK generation support
    });
}
exports.createSandbox = createSandbox;
function deleteSandbox(parentAccountId, sandboxAccountId) {
    return http_1.http.delete(parentAccountId, {
        url: `${SANDBOX_API_PATH}/${sandboxAccountId}`,
    });
}
exports.deleteSandbox = deleteSandbox;
function getSandboxUsageLimits(parentAccountId) {
    return http_1.http.get(parentAccountId, {
        url: `${SANDBOX_API_PATH}/parent/${parentAccountId}/usage`,
    });
}
exports.getSandboxUsageLimits = getSandboxUsageLimits;
function fetchSandboxHubData(accessToken, accountId, env = environments_1.ENVIRONMENTS.PROD) {
    const axiosConfig = (0, getAxiosConfig_1.getAxiosConfig)({
        env,
        url: `${SANDBOX_API_PATH}/self`,
        params: { portalId: accountId },
    });
    const reqWithToken = {
        ...axiosConfig,
        headers: {
            ...axiosConfig.headers,
            Authorization: `Bearer ${accessToken}`,
        },
    };
    return (0, axios_1.default)(reqWithToken);
}
exports.fetchSandboxHubData = fetchSandboxHubData;
