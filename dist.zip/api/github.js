"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.fetchRepoContents = exports.fetchRepoFileByDownloadUrl = exports.fetchRepoFile = exports.fetchRepoAsZip = exports.fetchRepoReleaseData = void 0;
const axios_1 = __importDefault(require("axios"));
const getAxiosConfig_1 = require("../http/getAxiosConfig");
const GITHUB_REPOS_API = 'https://api.github.com/repos';
const GITHUB_RAW_CONTENT_API_PATH = 'https://raw.githubusercontent.com';
function getAdditionalHeaders() {
    const headers = {};
    if (global && global.githubToken) {
        headers.authorization = `Bearer ${global.githubToken}`;
    }
    else if (process.env.GITHUB_TOKEN) {
        headers.authorization = `Bearer ${process.env.GITHUB_TOKEN}`;
    }
    return headers;
}
// Returns information about the repo's releases. Defaults to "latest" if no tag is provided
// https://docs.github.com/en/rest/releases/releases?apiVersion=2022-11-28#get-a-release-by-tag-name
function fetchRepoReleaseData(repoPath, tag = '') {
    const URL = `${GITHUB_REPOS_API}/${repoPath}/releases`;
    return axios_1.default.get(`${URL}/${tag ? `tags/${tag}` : 'latest'}`, {
        headers: {
            ...(0, getAxiosConfig_1.getDefaultUserAgentHeader)(),
            ...getAdditionalHeaders(),
        },
    });
}
exports.fetchRepoReleaseData = fetchRepoReleaseData;
// Returns the entire repo content as a zip, using the zipball_url from fetchRepoReleaseData()
// https://docs.github.com/en/rest/repos/contents?apiVersion=2022-11-28#download-a-repository-archive-zip
function fetchRepoAsZip(zipUrl) {
    return axios_1.default.get(zipUrl, {
        responseType: 'arraybuffer',
        headers: { ...(0, getAxiosConfig_1.getDefaultUserAgentHeader)(), ...getAdditionalHeaders() },
    });
}
exports.fetchRepoAsZip = fetchRepoAsZip;
// Returns the raw file contents via the raw.githubusercontent endpoint
function fetchRepoFile(repoPath, filePath, ref) {
    return axios_1.default.get(`${GITHUB_RAW_CONTENT_API_PATH}/${repoPath}/${ref}/${filePath}`, {
        headers: {
            ...(0, getAxiosConfig_1.getDefaultUserAgentHeader)(),
            ...getAdditionalHeaders(),
        },
    });
}
exports.fetchRepoFile = fetchRepoFile;
// Returns the raw file contents via the raw.githubusercontent endpoint
function fetchRepoFileByDownloadUrl(downloadUrl) {
    return axios_1.default.get(downloadUrl, {
        headers: { ...(0, getAxiosConfig_1.getDefaultUserAgentHeader)(), ...getAdditionalHeaders() },
        responseType: 'arraybuffer',
    });
}
exports.fetchRepoFileByDownloadUrl = fetchRepoFileByDownloadUrl;
// Returns the contents of a file or directory in a repository by path
// https://docs.github.com/en/rest/repos/contents?apiVersion=2022-11-28#get-repository-content
function fetchRepoContents(repoPath, path, ref) {
    const refQuery = ref ? `?ref=${ref}` : '';
    return axios_1.default.get(`${GITHUB_REPOS_API}/${repoPath}/contents/${path}${refQuery}`, {
        headers: {
            ...(0, getAxiosConfig_1.getDefaultUserAgentHeader)(),
            ...getAdditionalHeaders(),
        },
    });
}
exports.fetchRepoContents = fetchRepoContents;
