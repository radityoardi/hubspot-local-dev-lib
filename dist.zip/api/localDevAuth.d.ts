import { AxiosPromise } from 'axios';
import { Environment } from '../types/Config';
import { ScopeData, AccessTokenResponse, EnabledFeaturesResponse } from '../types/Accounts';
import { PublicAppInstallationData } from '../types/Apps';
export declare function fetchAccessToken(personalAccessKey: string, env?: Environment, portalId?: number): AxiosPromise<AccessTokenResponse>;
export declare function fetchScopeData(accountId: number, scopeGroup: string): AxiosPromise<ScopeData>;
export declare function fetchAppInstallationData(portalId: number, projectId: number, appUid: string, requiredScopeGroups: Array<string>, optionalScopeGroups?: Array<string>): AxiosPromise<PublicAppInstallationData>;
export declare function fetchEnabledFeatures(accountId: number): Promise<import("axios").AxiosResponse<EnabledFeaturesResponse, any>>;
