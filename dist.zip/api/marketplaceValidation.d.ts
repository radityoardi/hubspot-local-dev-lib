import { AxiosPromise } from 'axios';
import { Data, QueryParams } from '../types/Http';
import { GetValidationResultsResponse } from '../types/MarketplaceValidation';
export declare function requestValidation(accountId: number, data?: Data): AxiosPromise<number>;
export declare function getValidationStatus(accountId: number, params?: QueryParams): AxiosPromise<string>;
export declare function getValidationResults(accountId: number, params?: QueryParams): AxiosPromise<GetValidationResultsResponse>;
