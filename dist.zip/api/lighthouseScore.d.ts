import { AxiosPromise } from 'axios';
import { Data, QueryParams } from '../types/Http';
import { GetLighthouseScoreResponse, RequestLighthouseScoreResponse } from '../types/Lighthouse';
export declare function requestLighthouseScore(accountId: number, data?: Data): AxiosPromise<RequestLighthouseScoreResponse>;
export declare function getLighthouseScoreStatus(accountId: number, params?: QueryParams): AxiosPromise<string>;
export declare function getLighthouseScore(accountId: number, params?: QueryParams): AxiosPromise<GetLighthouseScoreResponse>;
