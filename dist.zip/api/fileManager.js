"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.fetchFolders = exports.fetchFiles = exports.fetchStat = exports.uploadFile = void 0;
const fs_1 = __importDefault(require("fs"));
const path_1 = __importDefault(require("path"));
const http_1 = require("../http");
const FILE_MANAGER_V2_API_PATH = 'filemanager/api/v2';
const FILE_MANAGER_V3_API_PATH = 'filemanager/api/v3';
function uploadFile(accountId, src, dest) {
    const directory = path_1.default.dirname(dest);
    const filename = path_1.default.basename(dest);
    const formData = {
        file: fs_1.default.createReadStream(src),
        fileName: filename,
        options: JSON.stringify({
            access: 'PUBLIC_INDEXABLE',
            overwrite: true,
        }),
    };
    if (directory && directory !== '.') {
        formData.folderPath = directory;
    }
    else {
        formData.folderPath = '/';
    }
    return http_1.http.post(accountId, {
        url: `${FILE_MANAGER_V3_API_PATH}/files/upload`,
        data: formData,
        headers: { 'Content-Type': 'multipart/form-data' },
    });
}
exports.uploadFile = uploadFile;
function fetchStat(accountId, src) {
    return http_1.http.get(accountId, {
        url: `${FILE_MANAGER_V2_API_PATH}/files/stat/${src}`,
    });
}
exports.fetchStat = fetchStat;
function fetchFiles(accountId, folderId, offset, archived) {
    return http_1.http.get(accountId, {
        url: `${FILE_MANAGER_V2_API_PATH}/files/`,
        params: {
            hidden: 0,
            offset: offset,
            folder_id: folderId,
            ...(!archived && { archived: 0 }),
        },
    });
}
exports.fetchFiles = fetchFiles;
function fetchFolders(accountId, folderId) {
    return http_1.http.get(accountId, {
        url: `${FILE_MANAGER_V2_API_PATH}/folders/`,
        params: {
            hidden: 0,
            parent_folder_id: folderId,
        },
    });
}
exports.fetchFolders = fetchFolders;
