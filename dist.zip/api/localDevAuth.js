"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.fetchEnabledFeatures = exports.fetchAppInstallationData = exports.fetchScopeData = exports.fetchAccessToken = void 0;
const getAxiosConfig_1 = require("../http/getAxiosConfig");
const http_1 = require("../http");
const environments_1 = require("../constants/environments");
const axios_1 = __importDefault(require("axios"));
const LOCALDEVAUTH_API_AUTH_PATH = 'localdevauth/v1/auth';
function fetchAccessToken(personalAccessKey, env = environments_1.ENVIRONMENTS.PROD, portalId) {
    const axiosConfig = (0, getAxiosConfig_1.getAxiosConfig)({
        env,
        localHostOverride: true,
        url: `${LOCALDEVAUTH_API_AUTH_PATH}/refresh`,
        data: {
            encodedOAuthRefreshToken: personalAccessKey,
        },
        params: portalId ? { portalId } : {},
    });
    return (0, axios_1.default)({
        ...axiosConfig,
        method: 'post',
    });
}
exports.fetchAccessToken = fetchAccessToken;
function fetchScopeData(accountId, scopeGroup) {
    return http_1.http.get(accountId, {
        url: `${LOCALDEVAUTH_API_AUTH_PATH}/check-scopes`,
        params: { scopeGroup },
    });
}
exports.fetchScopeData = fetchScopeData;
function fetchAppInstallationData(portalId, projectId, appUid, requiredScopeGroups, optionalScopeGroups = []) {
    return http_1.http.post(portalId, {
        url: `${LOCALDEVAUTH_API_AUTH_PATH}/install-info`,
        data: {
            portalId,
            projectId,
            sourceId: appUid,
            requiredScopeGroups,
            optionalScopeGroups,
        },
    });
}
exports.fetchAppInstallationData = fetchAppInstallationData;
async function fetchEnabledFeatures(accountId) {
    return http_1.http.get(accountId, {
        url: `${LOCALDEVAUTH_API_AUTH_PATH}/enabled-features`,
    });
}
exports.fetchEnabledFeatures = fetchEnabledFeatures;
