"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.fetchDeveloperTestAccountData = exports.deleteDeveloperTestAccount = exports.createDeveloperTestAccount = exports.fetchDeveloperTestAccounts = void 0;
const axios_1 = __importDefault(require("axios"));
const http_1 = require("../http");
const getAxiosConfig_1 = require("../http/getAxiosConfig");
const environments_1 = require("../constants/environments");
const api_1 = require("../constants/api");
const TEST_ACCOUNTS_API_PATH = 'integrators/test-portals/v2';
function fetchDeveloperTestAccounts(accountId) {
    return http_1.http.get(accountId, {
        url: TEST_ACCOUNTS_API_PATH,
    });
}
exports.fetchDeveloperTestAccounts = fetchDeveloperTestAccounts;
function createDeveloperTestAccount(accountId, accountName) {
    return http_1.http.post(accountId, {
        url: TEST_ACCOUNTS_API_PATH,
        data: { accountName, generatePersonalAccessKey: true },
        timeout: api_1.SANDBOX_TIMEOUT,
    });
}
exports.createDeveloperTestAccount = createDeveloperTestAccount;
function deleteDeveloperTestAccount(accountId, testAccountId) {
    return http_1.http.delete(accountId, {
        url: `${TEST_ACCOUNTS_API_PATH}/${testAccountId}`,
    });
}
exports.deleteDeveloperTestAccount = deleteDeveloperTestAccount;
function fetchDeveloperTestAccountData(accessToken, accountId, env = environments_1.ENVIRONMENTS.PROD) {
    const axiosConfig = (0, getAxiosConfig_1.getAxiosConfig)({
        env,
        url: `${TEST_ACCOUNTS_API_PATH}/self`,
        params: { portalId: accountId },
    });
    const reqWithToken = {
        ...axiosConfig,
        headers: {
            ...axiosConfig.headers,
            Authorization: `Bearer ${accessToken}`,
        },
    };
    return (0, axios_1.default)(reqWithToken);
}
exports.fetchDeveloperTestAccountData = fetchDeveloperTestAccountData;
