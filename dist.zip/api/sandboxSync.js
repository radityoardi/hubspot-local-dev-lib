"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.fetchTypes = exports.initiateSync = void 0;
const http_1 = require("../http");
const api_1 = require("../constants/api");
const SANDBOXES_SYNC_API_PATH = 'sandboxes-sync/v1';
function initiateSync(fromHubId, toHubId, tasks, sandboxHubId) {
    return http_1.http.post(fromHubId, {
        data: {
            command: 'SYNC',
            fromHubId,
            toHubId,
            sandboxHubId,
            tasks,
        },
        timeout: api_1.SANDBOX_TIMEOUT,
        url: `${SANDBOXES_SYNC_API_PATH}/tasks/initiate/async`,
    });
}
exports.initiateSync = initiateSync;
async function fetchTypes(accountId, toHubId) {
    return http_1.http.get(accountId, {
        url: `${SANDBOXES_SYNC_API_PATH}/types${toHubId ? `?toHubId=${toHubId}` : ''}`,
    });
}
exports.fetchTypes = fetchTypes;
