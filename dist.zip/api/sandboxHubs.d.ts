import { AxiosPromise } from 'axios';
import { Environment } from '../types/Config';
import { SandboxHubData, SandboxResponse, SandboxUsageLimitsResponse } from '../types/Sandbox';
export declare function createSandbox(accountId: number, name: string, type: 1 | 2): AxiosPromise<SandboxResponse>;
export declare function deleteSandbox(parentAccountId: number, sandboxAccountId: number): AxiosPromise<void>;
export declare function getSandboxUsageLimits(parentAccountId: number): AxiosPromise<SandboxUsageLimitsResponse>;
export declare function fetchSandboxHubData(accessToken: string, accountId: number, env?: Environment): AxiosPromise<SandboxHubData>;
