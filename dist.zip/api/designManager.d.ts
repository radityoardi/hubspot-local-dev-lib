import { AxiosPromise } from 'axios';
import { QueryParams } from '../types/Http';
import { FetchThemesResponse, FetchBuiltinMappingResponse } from '../types/DesignManager';
export declare function fetchThemes(accountId: number, params?: QueryParams): AxiosPromise<FetchThemesResponse>;
export declare function fetchBuiltinMapping(accountId: number): AxiosPromise<FetchBuiltinMappingResponse>;
