"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.fetchPublicAppMetadata = exports.fetchPublicAppProductionInstallCounts = exports.fetchPublicAppDeveloperTestAccountInstallData = exports.fetchPublicAppsForPortal = void 0;
const http_1 = require("../http");
const APPS_DEV_API_PATH = 'apps-dev/external/public/v3';
function fetchPublicAppsForPortal(accountId) {
    return http_1.http.get(accountId, {
        url: `${APPS_DEV_API_PATH}/full/portal`,
    });
}
exports.fetchPublicAppsForPortal = fetchPublicAppsForPortal;
function fetchPublicAppDeveloperTestAccountInstallData(appId, accountId) {
    return http_1.http.get(accountId, {
        url: `${APPS_DEV_API_PATH}/${appId}/test-portal-installs`,
    });
}
exports.fetchPublicAppDeveloperTestAccountInstallData = fetchPublicAppDeveloperTestAccountInstallData;
function fetchPublicAppProductionInstallCounts(appId, accountId) {
    return http_1.http.get(accountId, {
        url: `${APPS_DEV_API_PATH}/${appId}/install-counts-without-test-portals`,
    });
}
exports.fetchPublicAppProductionInstallCounts = fetchPublicAppProductionInstallCounts;
function fetchPublicAppMetadata(appId, accountId) {
    return http_1.http.get(accountId, {
        url: `${APPS_DEV_API_PATH}/${appId}/full`,
    });
}
exports.fetchPublicAppMetadata = fetchPublicAppMetadata;
