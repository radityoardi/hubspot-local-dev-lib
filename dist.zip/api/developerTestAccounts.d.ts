import { AxiosPromise } from 'axios';
import { DeveloperTestAccount, FetchDeveloperTestAccountsResponse } from '../types/developerTestAccounts';
import { Environment } from '../types/Config';
export declare function fetchDeveloperTestAccounts(accountId: number): AxiosPromise<FetchDeveloperTestAccountsResponse>;
export declare function createDeveloperTestAccount(accountId: number, accountName: string): AxiosPromise<DeveloperTestAccount>;
export declare function deleteDeveloperTestAccount(accountId: number, testAccountId: number): AxiosPromise<void>;
export declare function fetchDeveloperTestAccountData(accessToken: string, accountId: number, env?: Environment): AxiosPromise<DeveloperTestAccount>;
