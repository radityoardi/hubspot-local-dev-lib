import { AxiosPromise } from 'axios';
import { FetchSecretsResponse } from '../types/Secrets';
export declare function addSecret(accountId: number, key: string, value: string): AxiosPromise<void>;
export declare function updateSecret(accountId: number, key: string, value: string): AxiosPromise<void>;
export declare function deleteSecret(accountId: number, key: string): AxiosPromise<void>;
export declare function fetchSecrets(accountId: number): AxiosPromise<FetchSecretsResponse>;
