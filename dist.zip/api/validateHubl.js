"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.validateHubl = void 0;
const http_1 = require("../http");
const HUBL_VALIDATE_API_PATH = 'cos-rendering/v1/internal/validate';
function validateHubl(accountId, sourceCode, hublValidationOptions) {
    return http_1.http.post(accountId, {
        url: HUBL_VALIDATE_API_PATH,
        data: {
            template_source: sourceCode,
            ...hublValidationOptions,
        },
    });
}
exports.validateHubl = validateHubl;
