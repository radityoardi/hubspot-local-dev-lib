import { AxiosPromise } from 'axios';
import { InitiateSyncResponse, FetchTypesResponse, TaskRequestData } from '../types/Sandbox';
export declare function initiateSync(fromHubId: number, toHubId: number, tasks: Array<TaskRequestData>, sandboxHubId: number): AxiosPromise<InitiateSyncResponse>;
export declare function fetchTypes(accountId: number, toHubId: number): AxiosPromise<FetchTypesResponse>;
