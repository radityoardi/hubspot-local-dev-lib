import { AxiosPromise } from 'axios';
import { FetchSchemasResponse, Schema, CreateObjectsResponse } from '../types/Schemas';
export declare function batchCreateObjects(accountId: number, objectTypeId: string, objects: JSON): AxiosPromise<CreateObjectsResponse>;
export declare function createObjectSchema(accountId: number, schema: JSON): AxiosPromise<Schema>;
export declare function updateObjectSchema(accountId: number, schemaObjectType: string, schema: Schema): AxiosPromise<Schema>;
export declare function fetchObjectSchema(accountId: number, schemaObjectType: string): AxiosPromise<Schema>;
export declare function fetchObjectSchemas(accountId: number): AxiosPromise<FetchSchemasResponse>;
export declare function deleteObjectSchema(accountId: number, schemaObjectType: string): AxiosPromise<void>;
