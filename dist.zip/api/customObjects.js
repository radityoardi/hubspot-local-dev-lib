"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.deleteObjectSchema = exports.fetchObjectSchemas = exports.fetchObjectSchema = exports.updateObjectSchema = exports.createObjectSchema = exports.batchCreateObjects = void 0;
const http_1 = require("../http");
const CUSTOM_OBJECTS_API_PATH = 'crm/v3/objects';
const SCHEMA_API_PATH = 'crm-object-schemas/v3/schemas';
function batchCreateObjects(accountId, objectTypeId, objects) {
    return http_1.http.post(accountId, {
        url: `${CUSTOM_OBJECTS_API_PATH}/${objectTypeId}/batch/create`,
        data: objects,
    });
}
exports.batchCreateObjects = batchCreateObjects;
function createObjectSchema(accountId, schema) {
    return http_1.http.post(accountId, {
        url: SCHEMA_API_PATH,
        data: schema,
    });
}
exports.createObjectSchema = createObjectSchema;
function updateObjectSchema(accountId, schemaObjectType, schema) {
    return http_1.http.patch(accountId, {
        url: `${SCHEMA_API_PATH}/${schemaObjectType}`,
        data: schema,
    });
}
exports.updateObjectSchema = updateObjectSchema;
function fetchObjectSchema(accountId, schemaObjectType) {
    return http_1.http.get(accountId, {
        url: `${SCHEMA_API_PATH}/${schemaObjectType}`,
    });
}
exports.fetchObjectSchema = fetchObjectSchema;
function fetchObjectSchemas(accountId) {
    return http_1.http.get(accountId, {
        url: SCHEMA_API_PATH,
    });
}
exports.fetchObjectSchemas = fetchObjectSchemas;
function deleteObjectSchema(accountId, schemaObjectType) {
    return http_1.http.delete(accountId, {
        url: `${SCHEMA_API_PATH}/${schemaObjectType}`,
    });
}
exports.deleteObjectSchema = deleteObjectSchema;
