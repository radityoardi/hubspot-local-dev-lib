"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.getDirectoryContentsByPath = exports.moveFile = exports.deleteFile = exports.downloadDefault = exports.download = exports.fetchFileStream = exports.fetchModule = exports.upload = exports.createFileMapperNodeFromStreamResponse = exports.FILE_MAPPER_API_PATH = void 0;
const fs_1 = __importDefault(require("fs"));
const path_1 = __importDefault(require("path"));
const content_disposition_1 = __importDefault(require("content-disposition"));
const http_1 = require("../http");
const path_2 = require("../lib/path");
exports.FILE_MAPPER_API_PATH = 'content/filemapper/v1';
function createFileMapperNodeFromStreamResponse(filePath, response) {
    if (filePath[0] !== '/') {
        filePath = `/${filePath}`;
    }
    if (filePath[filePath.length - 1] === '/') {
        filePath = filePath.slice(0, filePath.length - 1);
    }
    const node = {
        source: null,
        path: filePath,
        name: path_1.default.basename(filePath),
        folder: false,
        children: [],
        createdAt: 0,
        updatedAt: 0,
    };
    if (!(response.headers && response.headers['content-disposition'])) {
        return node;
    }
    const { parameters } = content_disposition_1.default.parse(response.headers['content-disposition']);
    return {
        ...node,
        name: parameters.filename,
        createdAt: parseInt(parameters['creation-date'], 10) || 0,
        updatedAt: parseInt(parameters['modification-date'], 10) || 0,
    };
}
exports.createFileMapperNodeFromStreamResponse = createFileMapperNodeFromStreamResponse;
function upload(accountId, src, dest, options = {}) {
    return http_1.http.post(accountId, {
        url: `${exports.FILE_MAPPER_API_PATH}/upload/${encodeURIComponent(dest)}`,
        data: {
            file: fs_1.default.createReadStream(path_1.default.resolve((0, path_2.getCwd)(), src)),
        },
        headers: { 'Content-Type': 'multipart/form-data' },
        ...options,
    });
}
exports.upload = upload;
// Fetch a module by moduleId
function fetchModule(accountId, moduleId, options = {}) {
    return http_1.http.get(accountId, {
        url: `${exports.FILE_MAPPER_API_PATH}/modules/${moduleId}`,
        ...options,
    });
}
exports.fetchModule = fetchModule;
// Fetch a file by file path.
async function fetchFileStream(accountId, filePath, destination, options = {}) {
    const response = await http_1.http.getOctetStream(accountId, {
        url: `${exports.FILE_MAPPER_API_PATH}/stream/${encodeURIComponent(filePath)}`,
        ...options,
    }, destination);
    return createFileMapperNodeFromStreamResponse(filePath, response);
}
exports.fetchFileStream = fetchFileStream;
// Fetch a folder or file node by path.
function download(accountId, filepath, options = {}) {
    return http_1.http.get(accountId, {
        url: `${exports.FILE_MAPPER_API_PATH}/download/${encodeURIComponent(filepath)}`,
        ...options,
    });
}
exports.download = download;
// Fetch a folder or file node by path.
function downloadDefault(accountId, filepath, options = {}) {
    return http_1.http.get(accountId, {
        url: `${exports.FILE_MAPPER_API_PATH}/download-default/${filepath}`,
        ...options,
    });
}
exports.downloadDefault = downloadDefault;
// Delete a file or folder by path
function deleteFile(accountId, filePath) {
    return http_1.http.delete(accountId, {
        url: `${exports.FILE_MAPPER_API_PATH}/delete/${encodeURIComponent(filePath)}`,
    });
}
exports.deleteFile = deleteFile;
// Moves file from srcPath to destPath
function moveFile(accountId, srcPath, destPath) {
    return http_1.http.put(accountId, {
        url: `${exports.FILE_MAPPER_API_PATH}/rename/${srcPath}?path=${destPath}`,
        headers: { 'Content-Type': 'application/json' },
    });
}
exports.moveFile = moveFile;
// Get directory contents
function getDirectoryContentsByPath(accountId, path) {
    return http_1.http.get(accountId, {
        url: `${exports.FILE_MAPPER_API_PATH}/meta/${path}`,
    });
}
exports.getDirectoryContentsByPath = getDirectoryContentsByPath;
