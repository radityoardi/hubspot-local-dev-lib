"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.fetchBuiltinMapping = exports.fetchThemes = void 0;
const http_1 = require("../http");
const DESIGN_MANAGER_API_PATH = 'designmanager/v1';
function fetchThemes(accountId, params = {}) {
    return http_1.http.get(accountId, {
        url: `${DESIGN_MANAGER_API_PATH}/themes/combined`,
        params,
    });
}
exports.fetchThemes = fetchThemes;
function fetchBuiltinMapping(accountId) {
    return http_1.http.get(accountId, {
        url: `${DESIGN_MANAGER_API_PATH}/widgets/builtin-mapping`,
    });
}
exports.fetchBuiltinMapping = fetchBuiltinMapping;
