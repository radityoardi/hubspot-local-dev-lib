"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getValidationResults = exports.getValidationStatus = exports.requestValidation = void 0;
const http_1 = require("../http");
const VALIDATION_API_BASE = 'quality-engine/v1/validation';
function requestValidation(accountId, data = {}) {
    return http_1.http.post(accountId, {
        url: `${VALIDATION_API_BASE}/request`,
        data,
    });
}
exports.requestValidation = requestValidation;
function getValidationStatus(accountId, params = {}) {
    return http_1.http.get(accountId, {
        url: `${VALIDATION_API_BASE}/status`,
        params,
    });
}
exports.getValidationStatus = getValidationStatus;
function getValidationResults(accountId, params = {}) {
    return http_1.http.get(accountId, {
        url: `${VALIDATION_API_BASE}/results`,
        params,
    });
}
exports.getValidationResults = getValidationResults;
