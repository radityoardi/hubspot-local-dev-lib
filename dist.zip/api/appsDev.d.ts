import { AxiosPromise } from 'axios';
import { PublicApp, PublicAppInstallCounts, PublicAppDeveloperTestAccountInstallData, FetchPublicAppsForPortalResponse } from '../types/Apps';
export declare function fetchPublicAppsForPortal(accountId: number): AxiosPromise<FetchPublicAppsForPortalResponse>;
export declare function fetchPublicAppDeveloperTestAccountInstallData(appId: number, accountId: number): AxiosPromise<PublicAppDeveloperTestAccountInstallData>;
export declare function fetchPublicAppProductionInstallCounts(appId: number, accountId: number): AxiosPromise<PublicAppInstallCounts>;
export declare function fetchPublicAppMetadata(appId: number, accountId: number): AxiosPromise<PublicApp>;
