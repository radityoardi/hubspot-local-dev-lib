"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.fetchSecrets = exports.deleteSecret = exports.updateSecret = exports.addSecret = void 0;
const http_1 = require("../http");
const SECRETS_API_PATH = 'cms/v3/functions/secrets';
function addSecret(accountId, key, value) {
    return http_1.http.post(accountId, {
        url: SECRETS_API_PATH,
        data: {
            key,
            secret: value,
        },
    });
}
exports.addSecret = addSecret;
function updateSecret(accountId, key, value) {
    return http_1.http.put(accountId, {
        url: SECRETS_API_PATH,
        data: {
            key,
            secret: value,
        },
    });
}
exports.updateSecret = updateSecret;
function deleteSecret(accountId, key) {
    return http_1.http.delete(accountId, {
        url: `${SECRETS_API_PATH}/${key}`,
    });
}
exports.deleteSecret = deleteSecret;
function fetchSecrets(accountId) {
    return http_1.http.get(accountId, {
        url: `${SECRETS_API_PATH}`,
    });
}
exports.fetchSecrets = fetchSecrets;
