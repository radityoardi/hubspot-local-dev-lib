import { AxiosPromise } from 'axios';
import { QueryParams } from '../types/Http';
import { GetBuildStatusResponse, GetRoutesResponse } from '../types/Functions';
export declare function getRoutes(accountId: number): AxiosPromise<GetRoutesResponse>;
export declare function getFunctionLogs(accountId: number, route: string, params?: QueryParams): AxiosPromise;
export declare function getLatestFunctionLog(accountId: number, route: string): AxiosPromise;
export declare function buildPackage(accountId: number, folderPath: string): AxiosPromise<string>;
export declare function getBuildStatus(accountId: number, buildId: number): AxiosPromise<GetBuildStatusResponse>;
