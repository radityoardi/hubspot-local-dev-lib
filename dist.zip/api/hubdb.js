"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.deleteRows = exports.fetchRows = exports.createRows = exports.deleteTable = exports.publishTable = exports.updateTable = exports.createTable = exports.fetchTable = void 0;
const http_1 = require("../http");
const HUBDB_API_PATH = 'cms/v3/hubdb';
function fetchTable(accountId, tableId) {
    return http_1.http.get(accountId, {
        url: `${HUBDB_API_PATH}/tables/${tableId}`,
    });
}
exports.fetchTable = fetchTable;
function createTable(accountId, schema) {
    return http_1.http.post(accountId, {
        url: `${HUBDB_API_PATH}/tables`,
        data: schema,
    });
}
exports.createTable = createTable;
function updateTable(accountId, tableId, schema) {
    return http_1.http.patch(accountId, {
        url: `${HUBDB_API_PATH}/tables/${tableId}/draft`,
        data: schema,
    });
}
exports.updateTable = updateTable;
function publishTable(accountId, tableId) {
    return http_1.http.post(accountId, {
        url: `${HUBDB_API_PATH}/tables/${tableId}/draft/publish`,
        headers: {
            'Content-Type': 'application/json',
        },
    });
}
exports.publishTable = publishTable;
function deleteTable(accountId, tableId) {
    return http_1.http.delete(accountId, {
        url: `${HUBDB_API_PATH}/tables/${tableId}`,
    });
}
exports.deleteTable = deleteTable;
function createRows(accountId, tableId, rows) {
    return http_1.http.post(accountId, {
        url: `${HUBDB_API_PATH}/tables/${tableId}/rows/draft/batch/create`,
        data: { inputs: rows },
    });
}
exports.createRows = createRows;
function fetchRows(accountId, tableId, params = {}) {
    return http_1.http.get(accountId, {
        url: `${HUBDB_API_PATH}/tables/${tableId}/rows/draft`,
        params,
    });
}
exports.fetchRows = fetchRows;
function deleteRows(accountId, tableId, rowIds) {
    return http_1.http.post(accountId, {
        url: `${HUBDB_API_PATH}/tables/${tableId}/rows/draft/batch/purge`,
        data: { inputs: rowIds },
    });
}
exports.deleteRows = deleteRows;
