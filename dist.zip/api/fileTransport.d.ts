import { AxiosPromise } from 'axios';
export declare function createSchemaFromHubFile(accountId: number, filepath: string): AxiosPromise;
export declare function updateSchemaFromHubFile(accountId: number, filepath: string): AxiosPromise;
export declare function fetchHubFileSchema(accountId: number, objectName: string, path: string): AxiosPromise;
