"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.fetchHubFileSchema = exports.updateSchemaFromHubFile = exports.createSchemaFromHubFile = void 0;
const fs_1 = __importDefault(require("fs"));
const path_1 = __importDefault(require("path"));
const path_2 = require("../lib/path");
const http_1 = require("../http");
const HUBFILES_API_PATH = '/file-transport/v1/hubfiles';
function createSchemaFromHubFile(accountId, filepath) {
    const file = fs_1.default.createReadStream(path_1.default.resolve((0, path_2.getCwd)(), filepath));
    return http_1.http.post(accountId, {
        url: `${HUBFILES_API_PATH}/object-schemas`,
        data: {
            file,
        },
        headers: { 'Content-Type': 'multipart/form-data' },
    });
}
exports.createSchemaFromHubFile = createSchemaFromHubFile;
async function updateSchemaFromHubFile(accountId, filepath) {
    const file = fs_1.default.createReadStream(path_1.default.resolve((0, path_2.getCwd)(), filepath));
    return http_1.http.put(accountId, {
        url: `${HUBFILES_API_PATH}/object-schemas`,
        data: {
            file,
        },
        headers: { 'Content-Type': 'multipart/form-data' },
    });
}
exports.updateSchemaFromHubFile = updateSchemaFromHubFile;
async function fetchHubFileSchema(accountId, objectName, path) {
    return http_1.http.getOctetStream(accountId, {
        url: `${HUBFILES_API_PATH}/object-schemas/${objectName}`,
    }, path);
}
exports.fetchHubFileSchema = fetchHubFileSchema;
