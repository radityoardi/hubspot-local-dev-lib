"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getLighthouseScore = exports.getLighthouseScoreStatus = exports.requestLighthouseScore = void 0;
const http_1 = require("../http");
const LIGHTHOUSE_SCORE_API_BASE = 'quality-engine/v1/lighthouse';
function requestLighthouseScore(accountId, data = {}) {
    return http_1.http.post(accountId, {
        url: `${LIGHTHOUSE_SCORE_API_BASE}/request`,
        data,
    });
}
exports.requestLighthouseScore = requestLighthouseScore;
function getLighthouseScoreStatus(accountId, params = {}) {
    return http_1.http.get(accountId, {
        url: `${LIGHTHOUSE_SCORE_API_BASE}/status`,
        params,
    });
}
exports.getLighthouseScoreStatus = getLighthouseScoreStatus;
function getLighthouseScore(accountId, params = {}) {
    return http_1.http.get(accountId, {
        url: `${LIGHTHOUSE_SCORE_API_BASE}/scores`,
        params,
    });
}
exports.getLighthouseScore = getLighthouseScore;
