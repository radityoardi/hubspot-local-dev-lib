export declare function shouldIgnoreFile(file: string, isInProject?: boolean): boolean;
export declare function createIgnoreFilter(isInProject: boolean): (file: string) => boolean;
export declare function ignoreFile(filePath: string): void;
