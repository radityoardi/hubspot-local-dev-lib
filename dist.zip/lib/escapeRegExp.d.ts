export declare function escapeRegExp(string: string): string;
