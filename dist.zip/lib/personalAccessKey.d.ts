import { CLIAccount } from '../types/Accounts';
import { Environment } from '../types/Config';
import { AccessToken } from '../types/Accounts';
export declare function getAccessToken(personalAccessKey: string, env?: Environment, accountId?: number): Promise<AccessToken>;
export declare function accessTokenForPersonalAccessKey(accountId: number, forceRefresh?: boolean): Promise<string | undefined>;
export declare function enabledFeaturesForPersonalAccessKey(accountId: number): Promise<{
    [key: string]: number;
} | undefined>;
export declare function scopesOnAccessToken(accountId: number): Promise<Array<string>>;
export declare function updateConfigWithAccessToken(token: AccessToken, personalAccessKey: string, env?: Environment, name?: string, makeDefault?: boolean): Promise<CLIAccount | null>;
