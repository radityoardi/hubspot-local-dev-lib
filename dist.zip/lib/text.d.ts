export declare function commaSeparatedValues(arr: Array<string>, conjunction?: null | string, ifempty?: string): string;
export declare function toKebabCase(str: string): string;
