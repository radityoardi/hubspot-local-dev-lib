import { Environment } from '../types/Config';
export declare function getValidEnv(env?: Environment | null, maskedProductionValue?: Environment): Environment;
