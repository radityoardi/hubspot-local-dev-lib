import { Chalk } from 'chalk';
export declare const LOG_LEVEL: {
    NONE: number;
    DEBUG: number;
    LOG: number;
    WARN: number;
    ERROR: number;
};
/**
 * Chalk styles for logger strings.
 */
export declare const Styles: {
    debug: Chalk & {
        supportsColor: import("chalk").ColorSupport;
    };
    log: Chalk & {
        supportsColor: import("chalk").ColorSupport;
    };
    success: Chalk & {
        supportsColor: import("chalk").ColorSupport;
    };
    info: Chalk & {
        supportsColor: import("chalk").ColorSupport;
    };
    warn: Chalk & {
        supportsColor: import("chalk").ColorSupport;
    };
    error: Chalk & {
        supportsColor: import("chalk").ColorSupport;
    };
};
export declare function stylize(label: string, style: Chalk, args: any[]): any[];
export declare class Logger {
    error(...args: any[]): void;
    warn(...args: any[]): void;
    log(...args: any[]): void;
    success(...args: any[]): void;
    info(...args: any[]): void;
    debug(...args: any[]): void;
    group(...args: any[]): void;
    groupEnd(): void;
}
export declare function setLogger(logger: Logger): void;
export declare function setLogLevel(level: number): void;
export declare function shouldLog(level: number): boolean;
export declare function getLogLevel(): number;
export declare const logger: {
    error(...args: any[]): void;
    warn(...args: any[]): void;
    log(...args: any[]): void;
    success(...args: any[]): void;
    info(...args: any[]): void;
    debug(...args: any[]): void;
    group(...args: any[]): void;
    groupEnd(): void;
};
