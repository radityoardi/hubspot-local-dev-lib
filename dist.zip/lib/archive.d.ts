/// <reference types="node" />
/// <reference types="node" />
import { CopySourceToDestOptions } from '../types/Archive';
export declare function extractZipArchive(zip: Buffer, name: string, dest: string, { sourceDir, includesRootDir, hideLogs }?: CopySourceToDestOptions): Promise<boolean>;
