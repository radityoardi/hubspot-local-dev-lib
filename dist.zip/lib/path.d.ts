/// <reference types="node" />
import path from 'path';
export declare function convertToUnixPath(_path: string): string;
export declare function convertToLocalFileSystemPath(_path: string): string;
export declare function splitLocalPath(filepath: string, pathImplementation?: path.PlatformPath): Array<string>;
export declare function splitHubSpotPath(filepath: string): Array<string>;
export declare function getCwd(): string;
export declare function getExt(filepath: string): string;
export declare function getAllowedExtensions(allowList?: Array<string>): Set<string>;
export declare function isAllowedExtension(filepath: string, allowList?: Array<string>): boolean;
export declare function getAbsoluteFilePath(_path: string): string;
export declare function sanitizeFileName(fileName: string): string;
export declare function isValidPath(_path: string): boolean;
export declare function untildify(pathWithTilde: string): string;
