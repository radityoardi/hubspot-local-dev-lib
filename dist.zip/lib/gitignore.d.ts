import { GitInclusionResult } from '../types/Config';
export declare function checkAndAddConfigToGitignore(configPath: string): void;
export declare function checkGitInclusion(configPath: string): GitInclusionResult;
