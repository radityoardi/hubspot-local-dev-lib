/// <reference types="node" />
/// <reference types="node" />
import { GithubReleaseData, GithubRepoFile, RepoPath, CloneGithubRepoOptions } from '../types/Github';
export declare function fetchFileFromRepository(repoPath: RepoPath, filePath: string, ref: string): Promise<Buffer>;
export declare function fetchReleaseData(repoPath: RepoPath, tag?: string): Promise<GithubReleaseData>;
export declare function cloneGithubRepo(repoPath: RepoPath, dest: string, options?: CloneGithubRepoOptions): Promise<boolean>;
export declare function fetchGitHubRepoContentFromDownloadUrl(dest: string, downloadUrl: string): Promise<void>;
export declare function downloadGithubRepoContents(repoPath: RepoPath, contentPath: string, dest: string, ref?: string, filter?: (contentPiecePath: string, downloadPath: string) => boolean): Promise<void>;
export declare function listGithubRepoContents(repoPath: RepoPath, contentPath: string, fileFilter?: 'file' | 'dir'): Promise<GithubRepoFile[]>;
