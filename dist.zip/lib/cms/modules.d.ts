import { PathInput, ValidationResult, ModuleDefinition } from '../../types/Modules';
export declare const ValidationIds: {
    SRC_REQUIRED: string;
    DEST_REQUIRED: string;
    MODULE_FOLDER_REQUIRED: string;
    MODULE_TO_MODULE_NESTING: string;
    MODULE_NESTING: string;
};
export declare function validateSrcAndDestPaths(src?: PathInput, dest?: PathInput): Promise<Array<ValidationResult>>;
export declare function createModule(moduleDefinition: ModuleDefinition, name: string, dest: string, getInternalVersion: boolean, options?: {
    allowExistingDir: boolean;
}): Promise<void>;
export declare function retrieveDefaultModule(name: string | undefined, dest: string): Promise<import("../../types/Github").GithubRepoFile[] | undefined>;
export declare const isModuleHTMLFile: (filePath: string) => boolean;
