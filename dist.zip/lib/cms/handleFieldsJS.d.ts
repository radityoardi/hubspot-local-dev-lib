export declare class FieldsJs {
    projectDir: string;
    filePath: string;
    rootWriteDir: string;
    rejected: boolean;
    fieldOptions: string;
    outputPath?: string;
    toJSON?: () => JSON;
    constructor(projectDir: string, filePath: string, rootWriteDir?: string | null, fieldOptions?: string);
    init(): Promise<this>;
    convertFieldsJs(writeDir: string): Promise<string | void>;
    /**
     * If there has been a fields.json written to the output path, then copy it from the output
     * directory to the project directory, respecting the path within the output directory.
     * Ex: path/to/tmp/example.module/fields.json => path/to/project/example.module/fields.output.json
     */
    saveOutput(): void;
    /**
     * Resolves the relative path to the fields.js within the project directory and returns
     * directory name to write to in rootWriteDir directory.
     *
     * Ex: If rootWriteDir = 'path/to/temp', filePath = 'projectRoot/sample.module/fields.js'. Then getWriteDir() => path/to/temp/sample.module
     */
    getWriteDir(): string;
    getOutputPathPromise(): Promise<string | void>;
}
/**
 * Determines if file is a convertable fields.js file i.e., if it is called
 * 'fields.js' and in a root or in a module folder, and if convertFields flag is true.
 */
export declare function isConvertableFieldJs(rootDir: string, filePath: string, convertFields?: boolean): boolean;
export declare function createTmpDirSync(prefix: string): string;
export declare function cleanupTmpDirSync(tmpDir: string): void;
