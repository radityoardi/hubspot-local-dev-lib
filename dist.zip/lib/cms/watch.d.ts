import chokidar from 'chokidar';
import { WatchOptions, WatchErrorHandler } from '../../types/Files';
import { UploadFolderResults } from '../../types/Files';
export declare function watch(accountId: number, src: string, dest: string, { mode, remove, disableInitial, notify, commandOptions, filePaths, }: WatchOptions, postInitialUploadCallback?: ((result: Array<UploadFolderResults>) => void) | null, onUploadFolderError?: WatchErrorHandler, onQueueAddError?: WatchErrorHandler, onUploadFileError?: (file: string, dest: string, accountId: number) => WatchErrorHandler): chokidar.FSWatcher;
