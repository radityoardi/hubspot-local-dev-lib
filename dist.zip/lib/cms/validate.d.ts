import { LintResult } from '../../types/HublValidation';
export declare function lint(accountId: number, filepath: string, callback?: (lintResult: LintResult) => number): Promise<Array<Partial<LintResult>> | void>;
