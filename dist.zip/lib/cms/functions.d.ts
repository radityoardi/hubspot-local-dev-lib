import { FunctionConfig, FunctionConfigInfo, FunctionInfo, FunctionOptions } from '../../types/Functions';
export declare function isObjectOrFunction(value: object): boolean;
export declare function createEndpoint(endpointMethod: string, filename: string): {
    method: string;
    file: string;
};
export declare function createConfig({ endpointPath, endpointMethod, functionFile, }: FunctionConfigInfo): FunctionConfig;
export declare function createFunction(functionInfo: FunctionInfo, dest: string, options?: FunctionOptions): Promise<void>;
