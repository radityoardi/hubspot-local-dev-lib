import { FieldsJs } from './handleFieldsJS';
import { FileMapperInputOptions } from '../../types/Files';
import { UploadFolderResults, CommandOptions, FilePathsByType } from '../../types/Files';
import { Mode } from '../../types/Files';
export declare function getFilesByType(filePaths: Array<string>, projectDir: string, rootWriteDir: string | null, commandOptions: CommandOptions): Promise<[FilePathsByType, Array<FieldsJs>]>;
export declare function uploadFolder(accountId: number, src: string, dest: string, fileMapperOptions: FileMapperInputOptions, commandOptions?: CommandOptions, filePaths?: Array<string>, mode?: Mode | null): Promise<Array<UploadFolderResults>>;
export declare function hasUploadErrors(results: Array<UploadFolderResults>): boolean;
