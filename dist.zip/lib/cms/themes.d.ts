export declare function getThemeJSONPath(path: string): string | null;
export declare function getThemePreviewUrl(filePath: string, accountId: number): string | undefined;
