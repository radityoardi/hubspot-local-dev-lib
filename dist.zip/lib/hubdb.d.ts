import { AxiosResponse } from 'axios';
import { Row, Table } from '../types/Hubdb';
export declare function addRowsToHubDbTable(accountId: number, tableId: string, rows?: Array<Row>): Promise<{
    tableId: string;
    rowCount: number;
}>;
export declare function createHubDbTable(accountId: number, src: string): Promise<{
    tableId: string;
    rowCount: number;
}>;
export declare function updateHubDbTable(accountId: number, tableId: string, src: string): Promise<AxiosResponse<Table, any>>;
export declare function downloadHubDbTable(accountId: number, tableId: string, dest: string): Promise<{
    filePath: string;
}>;
export declare function clearHubDbTableRows(accountId: number, tableId: string): Promise<{
    deletedRowCount: number;
}>;
