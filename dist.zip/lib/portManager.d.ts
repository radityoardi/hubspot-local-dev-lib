import { RequestPortsData } from '../types/PortManager';
export declare const BASE_URL: string;
export declare function startPortManagerServer(): Promise<void>;
export declare function stopPortManagerServer(): Promise<void>;
export declare function requestPorts(portData: Array<RequestPortsData>): Promise<{
    [instanceId: string]: number;
}>;
export declare function deleteServerInstance(serverInstanceId: string): Promise<void>;
export declare function portManagerHasActiveServers(): Promise<boolean>;
