export declare function uploadFolder(accountId: number, src: string, dest: string): Promise<void>;
export declare function downloadFileOrFolder(accountId: number, src: string, dest: string, overwrite?: boolean, includeArchived?: boolean): Promise<void>;
