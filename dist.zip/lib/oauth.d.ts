import { OAuth2Manager } from '../models/OAuth2Manager';
import { FlatAccountFields } from '../types/Accounts';
export declare function getOauthManager(accountId: number, accountConfig: FlatAccountFields): OAuth2Manager | undefined;
export declare function addOauthToAccountConfig(oauth: OAuth2Manager): void;
