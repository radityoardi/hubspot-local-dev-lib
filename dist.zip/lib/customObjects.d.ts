import { Schema } from '../types/Schemas';
export declare function getResolvedPath(dest?: string, name?: string): string;
export declare function writeSchemaToDisk(schema: Schema, dest?: string): Promise<void>;
export declare function downloadSchemas(accountId: number, dest?: string): Promise<Array<Schema>>;
export declare function downloadSchema(accountId: number, schemaObjectType: string, dest?: string): Promise<Schema>;
