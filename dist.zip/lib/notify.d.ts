export declare function triggerNotify(filePathToNotify: string | undefined, actionType: string, filePath: string, actionPromise: Promise<void>): void;
