export declare const getHubSpotWebsiteOrigin: (env: string) => string;
export declare function getHubSpotApiOrigin(env?: string, useLocalHost?: boolean): string;
