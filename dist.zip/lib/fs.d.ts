import { FileData } from '../types/Files';
export declare function getFileInfoAsync(dir: string, file: string): Promise<FileData>;
export declare function flattenAndRemoveSymlinks(filesData: Array<FileData>): Array<string>;
export declare function walk(dir: string): Promise<Array<string>>;
