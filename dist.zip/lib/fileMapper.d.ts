import { FileMapperNode, Mode, FileMapperOptions, FileMapperInputOptions, PathTypeData, RecursiveFileMapperCallback } from '../types/Files';
export declare function isPathToFile(filepath: string): boolean;
export declare function isPathToModule(filepath: string): boolean;
export declare function isPathToRoot(filepath: string): boolean;
export declare function isPathToHubspot(filepath: string): boolean;
export declare function getFileMapperQueryValues(mode?: Mode | null, { staging, assetVersion }?: FileMapperInputOptions): FileMapperOptions;
export declare function getTypeDataFromPath(src: string): PathTypeData;
export declare function recurseFolder(node: FileMapperNode, callback: RecursiveFileMapperCallback, filepath?: string, depth?: number): boolean;
export declare function writeUtimes(accountId: number, filepath: string, node: FileMapperNode): Promise<void>;
export declare function fetchFolderFromApi(accountId: number, src: string, mode?: Mode, options?: FileMapperInputOptions): Promise<FileMapperNode>;
/**
 * Fetch a file/folder and write to local file system.
 *
 * @async
 * @param {FileMapperInputArguments} input
 * @returns {Promise}
 */
export declare function downloadFileOrFolder(accountId: number, src: string, dest: string, mode?: Mode, options?: FileMapperInputOptions): Promise<void>;
