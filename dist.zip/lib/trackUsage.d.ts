export declare function trackUsage(eventName: string, eventClass: string, meta?: {}, accountId?: number): Promise<void>;
