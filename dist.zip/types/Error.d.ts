export interface GenericError extends Error {
    [key: string]: any;
}
export interface BaseError extends Error {
    name: string;
    message: string;
    errno?: number | null;
    code?: string | null;
    syscall?: string | null;
    reason?: string;
    status?: number;
    error?: BaseError;
    errors?: Array<BaseError>;
}
export interface ValidationError extends BaseError {
    errorTokens?: {
        line: number;
    };
    context?: {
        requiredScopes?: string[];
    };
}
export type FileSystemErrorContext = {
    filepath?: string;
    operation?: 'write' | 'read';
    accountId?: number;
    dest?: string;
};
export interface HubSpotHttpErrorContext extends FileSystemErrorContext {
    request?: string;
    payload?: string;
    projectName?: string;
}
export type OptionalError = BaseError | null | undefined;
export type ErrorContext = {
    accountId?: number;
};
