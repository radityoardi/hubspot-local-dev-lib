import { ValueOf } from './Utils';
import { OptionalError } from './Error';
export declare const MIGRATION_STATUS: {
    readonly BUILDING: "BUILDING";
    readonly FAILURE: "FAILURE";
    readonly PREPARING: "PREPARING";
    readonly PENDING: "PENDING";
    readonly SUCCESS: "SUCCESS";
};
export type MigrateAppResponse = {
    id: number;
    status: ValueOf<typeof MIGRATION_STATUS>;
};
export type CloneAppResponse = {
    exportId: number;
    status: ValueOf<typeof MIGRATION_STATUS>;
};
export type PollAppResponse = {
    id: number;
    project?: {
        id: number;
        name: string;
        buildId: number;
        deployId: number;
    };
    error?: OptionalError;
    status: ValueOf<typeof MIGRATION_STATUS>;
};
