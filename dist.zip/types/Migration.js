"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.MIGRATION_STATUS = void 0;
exports.MIGRATION_STATUS = {
    BUILDING: 'BUILDING',
    FAILURE: 'FAILURE',
    PREPARING: 'PREPARING',
    PENDING: 'PENDING',
    SUCCESS: 'SUCCESS',
};
