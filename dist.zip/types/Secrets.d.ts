export type FetchSecretsResponse = {
    results: Array<string>;
};
