export type FieldsArray<T> = Array<T | FieldsArray<T>>;
