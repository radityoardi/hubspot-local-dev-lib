export declare function getGitignoreFiles(configPath: string): Array<string>;
export declare function isConfigPathInGitRepo(configPath: string): boolean;
export declare function configFilenameIsIgnoredByGitignore(ignoreFiles: Array<string>, configPath: string): boolean;
