"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.PortManagerServer = void 0;
const express_1 = __importDefault(require("express"));
const cors_1 = __importDefault(require("cors"));
const detectPort_1 = require("./detectPort");
const ports_1 = require("../constants/ports");
const errors_1 = require("../errors");
const logger_1 = require("../lib/logger");
const lang_1 = require("./lang");
const i18nKey = 'utils.PortManagerServer';
class _PortManagerServer {
    app;
    server;
    serverPortMap;
    constructor() {
        this.serverPortMap = {};
    }
    async init() {
        if (this.app) {
            throw new Error((0, lang_1.i18n)(`${i18nKey}.errors.duplicateInstance`));
        }
        this.app = (0, express_1.default)();
        this.app.use(express_1.default.json());
        this.app.use((0, cors_1.default)());
        this.setupRoutes();
        try {
            this.server = await this.listen();
        }
        catch (e) {
            if ((0, errors_1.isSystemError)(e) && e.code === 'EADDRINUSE') {
                throw new Error((0, lang_1.i18n)(`${i18nKey}.errors.portInUse`, {
                    port: ports_1.PORT_MANAGER_SERVER_PORT,
                }), { cause: e });
            }
            throw e;
        }
    }
    reset() {
        this.app = undefined;
        this.server = undefined;
        this.serverPortMap = {};
    }
    listen() {
        return new Promise((resolve, reject) => {
            const server = this.app.listen(ports_1.PORT_MANAGER_SERVER_PORT, () => {
                logger_1.logger.debug((0, lang_1.i18n)(`${i18nKey}.started`, {
                    port: ports_1.PORT_MANAGER_SERVER_PORT,
                }));
                resolve(server);
            }).on('error', (err) => {
                reject(err);
            });
        });
    }
    setupRoutes() {
        if (!this.app) {
            return;
        }
        this.app.get('/servers', this.getServers);
        this.app.get('/servers/:instanceId', this.getServerPortByInstanceId);
        this.app.post('/servers', this.assignPortsToServers);
        this.app.delete('/servers/:instanceId', this.deleteServerInstance);
        this.app.post('/close', this.closeServer);
    }
    setPort(instanceId, port) {
        logger_1.logger.debug((0, lang_1.i18n)(`${i18nKey}.setPort`, { instanceId, port }));
        this.serverPortMap[instanceId] = port;
    }
    deletePort(instanceId) {
        logger_1.logger.debug((0, lang_1.i18n)(`${i18nKey}.deletedPort`, {
            instanceId,
            port: this.serverPortMap[instanceId],
        }));
        delete this.serverPortMap[instanceId];
    }
    send404(res, instanceId) {
        res
            .status(404)
            .send((0, lang_1.i18n)(`${i18nKey}.errors.404`, { instanceId: instanceId }));
    }
    getServers = async (req, res) => {
        res.send({
            servers: this.serverPortMap,
            count: Object.keys(this.serverPortMap).length,
        });
    };
    getServerPortByInstanceId = (req, res) => {
        const { instanceId } = req.params;
        const port = this.serverPortMap[instanceId];
        if (port) {
            res.send({ port });
        }
        else {
            this.send404(res, instanceId);
        }
    };
    assignPortsToServers = async (req, res) => {
        const { portData } = req.body;
        const portPromises = [];
        for (let i = 0; i < portData.length; i++) {
            const { port, instanceId } = portData[i];
            if (this.serverPortMap[instanceId]) {
                res.status(409).send((0, lang_1.i18n)(`${i18nKey}.errors.409`, {
                    instanceId,
                    port: this.serverPortMap[instanceId],
                }));
                return;
            }
            else if (port && (port < ports_1.MIN_PORT_NUMBER || port > ports_1.MAX_PORT_NUMBER)) {
                res.status(400).send((0, lang_1.i18n)(`${i18nKey}.errors.400`, {
                    minPort: ports_1.MIN_PORT_NUMBER,
                    maxPort: ports_1.MAX_PORT_NUMBER,
                }));
                return;
            }
            else {
                const promise = new Promise(resolve => {
                    (0, detectPort_1.detectPort)(port, Object.values(this.serverPortMap)).then(resolvedPort => {
                        resolve({
                            [instanceId]: resolvedPort,
                        });
                    });
                });
                portPromises.push(promise);
            }
        }
        const portList = await Promise.all(portPromises);
        const ports = portList.reduce((a, c) => Object.assign(a, c));
        for (const instanceId in ports) {
            this.setPort(instanceId, ports[instanceId]);
        }
        res.send({ ports });
    };
    deleteServerInstance = (req, res) => {
        const { instanceId } = req.params;
        const port = this.serverPortMap[instanceId];
        if (port) {
            this.deletePort(instanceId);
            res.sendStatus(200);
        }
        else {
            this.send404(res, instanceId);
        }
    };
    closeServer = (req, res) => {
        if (this.server) {
            logger_1.logger.debug((0, lang_1.i18n)(`${i18nKey}.close`));
            res.sendStatus(200);
            this.server.close();
            this.reset();
        }
    };
}
exports.PortManagerServer = new _PortManagerServer();
