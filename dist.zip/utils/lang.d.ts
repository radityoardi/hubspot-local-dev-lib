import { LanguageObject, LangKey, InterpolationData } from '../types/Lang';
export declare function interpolate(stringValue: string, interpolationData: InterpolationData): string;
export declare function i18n(lookupDotNotation: LangKey, options?: {
    [identifier: string]: string | number;
}): string;
export declare const setLangData: (newLocale: string, newLangObj: LanguageObject) => void;
