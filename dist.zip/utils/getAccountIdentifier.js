"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getDefaultAccount = exports.getAccounts = exports.getAccountIdentifier = void 0;
function getAccountIdentifier(account) {
    if (!account) {
        return undefined;
    }
    else if (Object.hasOwn(account, 'portalId')) {
        return account.portalId;
    }
    else if (Object.hasOwn(account, 'accountId')) {
        return account.accountId;
    }
}
exports.getAccountIdentifier = getAccountIdentifier;
function getAccounts(config) {
    if (!config) {
        return [];
    }
    else if (Object.hasOwn(config, 'portals')) {
        return config.portals;
    }
    else if (Object.hasOwn(config, 'accounts')) {
        return config.accounts;
    }
    return [];
}
exports.getAccounts = getAccounts;
function getDefaultAccount(config) {
    if (!config) {
        return undefined;
    }
    else if (Object.hasOwn(config, 'defaultPortal')) {
        return config.defaultPortal;
    }
    else if (Object.hasOwn(config, 'defaultAccount')) {
        return config.defaultAccount;
    }
}
exports.getDefaultAccount = getDefaultAccount;
