export declare function detectPort(port?: number | null, exclude?: Array<number>): Promise<number>;
