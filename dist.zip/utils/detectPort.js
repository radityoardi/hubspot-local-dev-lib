"use strict";
/*
From https://github.com/node-modules/detect-port/tree/master

The MIT License (MIT)

Copyright (c) 2014 - present node-modules and other contributors

Permission is hereby granted, free of charge, to any person obtaining a copy of
this software and associated documentation files (the "Software"), to deal in
the Software without restriction, including without limitation the rights to
use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of
the Software, and to permit persons to whom the Software is furnished to do so,
subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS
FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.detectPort = void 0;
const net_1 = __importDefault(require("net"));
const address_1 = require("address");
const ports_1 = require("../constants/ports");
const lang_1 = require("./lang");
const i18nKey = 'utils.detectPort';
function detectPort(port, exclude = []) {
    if (port && (port < ports_1.MIN_PORT_NUMBER || port > ports_1.MAX_PORT_NUMBER)) {
        throw new Error((0, lang_1.i18n)(`${i18nKey}.errors.invalidPort`, {
            minPort: ports_1.MIN_PORT_NUMBER,
            maxPort: ports_1.MAX_PORT_NUMBER,
        }));
    }
    const portToUse = port || 0;
    const maxPort = Math.min(portToUse + 10, ports_1.MAX_PORT_NUMBER);
    return new Promise(resolve => {
        tryListen(portToUse, maxPort, exclude, (_, resolvedPort) => {
            resolve(resolvedPort);
        });
    });
}
exports.detectPort = detectPort;
function tryListen(port, maxPort, exclude, callback) {
    const shouldGiveUp = port >= maxPort;
    const nextPort = shouldGiveUp ? 0 : port + 1;
    const nextMaxPort = shouldGiveUp ? 0 : maxPort;
    listen(port, undefined, (err, realPort) => {
        // ignore random listening
        if (port === 0) {
            return callback(err, realPort);
        }
        if (exclude.includes(port)) {
            return tryListen(nextPort, nextMaxPort, exclude, callback);
        }
        if (err) {
            return tryListen(nextPort, nextMaxPort, exclude, callback);
        }
        // 2. check 0.0.0.0
        listen(port, '0.0.0.0', err => {
            if (err) {
                return tryListen(nextPort, nextMaxPort, exclude, callback);
            }
            // 3. check localhost
            listen(port, 'localhost', err => {
                if (err && err.code !== 'EADDRNOTAVAIL') {
                    return tryListen(nextPort, nextMaxPort, exclude, callback);
                }
                // 4. check current ip
                listen(port, (0, address_1.ip)(), (err, realPort) => {
                    if (err) {
                        return tryListen(nextPort, nextMaxPort, exclude, callback);
                    }
                    callback(null, realPort);
                });
            });
        });
    });
}
function listen(port, hostname, callback) {
    const server = new net_1.default.Server();
    server.on('error', (err) => {
        server.close();
        if (err.code === 'ENOTFOUND') {
            return callback(null, port);
        }
        return callback(err, 0);
    });
    server.listen(port, hostname, () => {
        const addressInfo = server.address();
        server.close();
        return callback(null, addressInfo.port);
    });
}
