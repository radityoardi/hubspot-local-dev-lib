"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.configFilenameIsIgnoredByGitignore = exports.isConfigPathInGitRepo = exports.getGitignoreFiles = void 0;
const fs_extra_1 = __importDefault(require("fs-extra"));
const path_1 = __importDefault(require("path"));
const ignore_1 = __importDefault(require("ignore"));
const findup_sync_1 = __importDefault(require("findup-sync"));
const GITIGNORE_FILE = '.gitignore';
function makeComparisonDir(filepath) {
    if (typeof filepath !== 'string')
        return null;
    // Append sep to make comparisons easier e.g. 'foos'.startsWith('foo')
    return path_1.default.dirname(path_1.default.resolve(filepath)).toLowerCase() + path_1.default.sep;
}
function getGitComparisonDir() {
    return makeComparisonDir((0, findup_sync_1.default)('.git'));
}
// Get all .gitignore files since they can cascade down directory structures
function getGitignoreFiles(configPath) {
    const gitDir = getGitComparisonDir();
    const files = [];
    if (!gitDir) {
        // Not in git
        return files;
    }
    // Start findup from config dir
    let cwd = configPath && path_1.default.dirname(configPath);
    while (cwd) {
        const ignorePath = (0, findup_sync_1.default)(GITIGNORE_FILE, { cwd });
        const cmpIgnorePath = makeComparisonDir(ignorePath);
        const cmpGitDir = makeComparisonDir(gitDir);
        if (ignorePath &&
            cmpIgnorePath &&
            cmpGitDir &&
            // Stop findup after .git dir is reached
            cmpIgnorePath.startsWith(cmpGitDir)) {
            const file = path_1.default.resolve(ignorePath);
            files.push(file);
            cwd = path_1.default.resolve(path_1.default.dirname(file) + '..');
        }
        else {
            cwd = null;
        }
    }
    return files;
}
exports.getGitignoreFiles = getGitignoreFiles;
function isConfigPathInGitRepo(configPath) {
    const gitDir = getGitComparisonDir();
    if (!gitDir)
        return false;
    const configDir = makeComparisonDir(configPath);
    if (!configDir)
        return false;
    return configDir.startsWith(gitDir);
}
exports.isConfigPathInGitRepo = isConfigPathInGitRepo;
function configFilenameIsIgnoredByGitignore(ignoreFiles, configPath) {
    return ignoreFiles.some(gitignore => {
        const gitignoreContents = fs_extra_1.default.readFileSync(gitignore).toString();
        const gitignoreConfig = (0, ignore_1.default)().add(gitignoreContents);
        if (gitignoreConfig.ignores(path_1.default.relative(path_1.default.dirname(gitignore), configPath))) {
            return true;
        }
        return false;
    });
}
exports.configFilenameIsIgnoredByGitignore = configFilenameIsIgnoredByGitignore;
