"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.isModuleFolderChild = exports.isModuleFolder = exports.isPathInput = void 0;
const path_1 = __importDefault(require("path"));
const path_2 = require("../../lib/path");
const extensions_1 = require("../../constants/extensions");
const lang_1 = require("../lang");
const i18nKey = 'utils.cms.modules';
const isBool = (x) => !!x === x;
function isPathInput(pathInput) {
    return !!(pathInput &&
        typeof pathInput.path === 'string' &&
        (isBool(pathInput.isLocal) || isBool(pathInput.isHubSpot)));
}
exports.isPathInput = isPathInput;
function throwInvalidPathInput(pathInput) {
    if (isPathInput(pathInput))
        return;
    throw new Error((0, lang_1.i18n)(`${i18nKey}.throwInvalidPathInput`));
}
function isModuleFolder(pathInput) {
    throwInvalidPathInput(pathInput);
    const _path = pathInput.isHubSpot
        ? path_1.default.posix.normalize(pathInput.path)
        : path_1.default.normalize(pathInput.path);
    return (0, path_2.getExt)(_path) === extensions_1.MODULE_EXTENSION;
}
exports.isModuleFolder = isModuleFolder;
function isModuleFolderChild(pathInput, ignoreLocales = false) {
    throwInvalidPathInput(pathInput);
    let pathParts = [];
    if (pathInput.isLocal) {
        pathParts = (0, path_2.splitLocalPath)(pathInput.path);
    }
    else if (pathInput.isHubSpot) {
        pathParts = (0, path_2.splitHubSpotPath)(pathInput.path);
    }
    const { length } = pathParts;
    // Not a child path?
    if (length <= 1)
        return false;
    // Check if we should ignore this file
    if (ignoreLocales && pathParts.find(part => part === '_locales')) {
        return false;
    }
    // Check if any parent folders are module folders.
    return pathParts
        .slice(0, length - 1)
        .some(part => isModuleFolder({ ...pathInput, path: part }));
}
exports.isModuleFolderChild = isModuleFolderChild;
