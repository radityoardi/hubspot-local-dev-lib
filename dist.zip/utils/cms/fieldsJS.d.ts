import { FieldsArray } from '../../types/FieldsJS';
export declare function fieldsArrayToJson<T>(fields: FieldsArray<T>): string;
