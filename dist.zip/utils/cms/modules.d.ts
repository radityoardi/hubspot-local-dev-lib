import { PathInput } from '../../types/Modules';
export declare function isPathInput(pathInput?: PathInput): boolean;
export declare function isModuleFolder(pathInput: PathInput): boolean;
export declare function isModuleFolderChild(pathInput: PathInput, ignoreLocales?: boolean): boolean;
