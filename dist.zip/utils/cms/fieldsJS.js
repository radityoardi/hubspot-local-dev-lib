"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.fieldsArrayToJson = void 0;
/*
 * Polyfill for `Array.flat(Infinity)` since the `flat` is only available for Node v11+
 * https://stackoverflow.com/a/15030117
 */
function flattenArray(arr) {
    return arr.reduce((flat, toFlatten) => {
        return flat.concat(Array.isArray(toFlatten) ? flattenArray(toFlatten) : toFlatten);
    }, []);
}
//Transform fields array to JSON
function fieldsArrayToJson(fields) {
    const flattened = flattenArray(fields);
    return JSON.stringify(flattened, null, 2);
}
exports.fieldsArrayToJson = fieldsArrayToJson;
