import { CLIAccount, GenericAccount } from '../types/Accounts';
import { CLIConfig } from '../types/Config';
export declare function getAccountIdentifier(account?: GenericAccount | null): number | undefined;
export declare function getAccounts(config?: CLIConfig | null): Array<CLIAccount>;
export declare function getDefaultAccount(config?: CLIConfig | null): string | number | undefined;
