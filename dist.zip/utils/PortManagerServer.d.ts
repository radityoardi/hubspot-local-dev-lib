/// <reference types="node" />
import { Express, Request, Response } from 'express';
import { Server } from 'http';
import { RequestPortsData, ServerPortMap } from '../types/PortManager';
declare class _PortManagerServer {
    app?: Express;
    server?: Server;
    serverPortMap: ServerPortMap;
    constructor();
    init(): Promise<void>;
    reset(): void;
    listen(): Promise<Server>;
    setupRoutes(): void;
    setPort(instanceId: string, port: number): void;
    deletePort(instanceId: string): void;
    send404(res: Response, instanceId: string): void;
    getServers: (req: Request, res: Response) => Promise<void>;
    getServerPortByInstanceId: (req: Request, res: Response) => void;
    assignPortsToServers: (req: Request<never, never, {
        portData: Array<RequestPortsData>;
    }>, res: Response) => Promise<void>;
    deleteServerInstance: (req: Request, res: Response) => void;
    closeServer: (req: Request, res: Response) => void;
}
export declare const PortManagerServer: _PortManagerServer;
export {};
