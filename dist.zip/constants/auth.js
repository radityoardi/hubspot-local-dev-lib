"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SCOPE_GROUPS = exports.AUTH_METHODS = exports.OAUTH_SCOPES = exports.DEFAULT_OAUTH_SCOPES = exports.PERSONAL_ACCESS_KEY_AUTH_METHOD = exports.OAUTH_AUTH_METHOD = exports.API_KEY_AUTH_METHOD = void 0;
exports.API_KEY_AUTH_METHOD = {
    value: 'apikey',
    name: 'API Key',
};
exports.OAUTH_AUTH_METHOD = {
    value: 'oauth2',
    name: 'OAuth2',
};
exports.PERSONAL_ACCESS_KEY_AUTH_METHOD = {
    value: 'personalaccesskey',
    name: 'Personal Access Key',
};
exports.DEFAULT_OAUTH_SCOPES = ['content'];
exports.OAUTH_SCOPES = [
    {
        name: 'All CMS APIs, Calendar API, Email and Email Events APIs',
        value: 'content',
        checked: true,
    },
    {
        name: 'HubDB API',
        value: 'hubdb',
    },
    {
        name: 'File Manager API',
        value: 'files',
    },
];
exports.AUTH_METHODS = {
    api: exports.API_KEY_AUTH_METHOD,
    oauth: exports.OAUTH_AUTH_METHOD,
};
exports.SCOPE_GROUPS = {
    CMS_FUNCTIONS: 'cms.functions.read_write',
};
