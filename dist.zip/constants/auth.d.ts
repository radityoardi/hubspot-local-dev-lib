export declare const API_KEY_AUTH_METHOD: {
    readonly value: "apikey";
    readonly name: "API Key";
};
export declare const OAUTH_AUTH_METHOD: {
    readonly value: "oauth2";
    readonly name: "OAuth2";
};
export declare const PERSONAL_ACCESS_KEY_AUTH_METHOD: {
    readonly value: "personalaccesskey";
    readonly name: "Personal Access Key";
};
export declare const DEFAULT_OAUTH_SCOPES: readonly ["content"];
export declare const OAUTH_SCOPES: readonly [{
    readonly name: "All CMS APIs, Calendar API, Email and Email Events APIs";
    readonly value: "content";
    readonly checked: true;
}, {
    readonly name: "HubDB API";
    readonly value: "hubdb";
}, {
    readonly name: "File Manager API";
    readonly value: "files";
}];
export declare const AUTH_METHODS: {
    api: {
        readonly value: "apikey";
        readonly name: "API Key";
    };
    oauth: {
        readonly value: "oauth2";
        readonly name: "OAuth2";
    };
};
export declare const SCOPE_GROUPS: {
    CMS_FUNCTIONS: string;
};
