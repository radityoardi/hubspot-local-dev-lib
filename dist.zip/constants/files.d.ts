export declare const STAT_TYPES: {
    readonly FILE: "file";
    readonly SYMBOLIC_LINK: "symlink";
    readonly DIRECTORY: "dir";
};
export declare const MODE: {
    readonly draft: "draft";
    readonly publish: "publish";
};
export declare const DEFAULT_MODE: "publish";
export declare const FILE_UPLOAD_RESULT_TYPES: {
    readonly SUCCESS: "SUCCESS";
    readonly FAILURE: "FAILURE";
};
export declare const FILE_TYPES: {
    readonly other: "otherFiles";
    readonly module: "moduleFiles";
    readonly cssAndJs: "cssAndJsFiles";
    readonly template: "templateFiles";
    readonly json: "jsonFiles";
};
