"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.HUBSPOT_ACCOUNT_TYPE_STRINGS = exports.HUBSPOT_ACCOUNT_TYPES = exports.MIN_HTTP_TIMEOUT = exports.HUBSPOT_CONFIGURATION_FILE = exports.HUBSPOT_CONFIGURATION_FOLDER = exports.DEFAULT_HUBSPOT_CONFIG_YAML_FILE_NAME = void 0;
const lang_1 = require("../utils/lang");
exports.DEFAULT_HUBSPOT_CONFIG_YAML_FILE_NAME = 'hubspot.config.yml';
exports.HUBSPOT_CONFIGURATION_FOLDER = '.hubspot';
exports.HUBSPOT_CONFIGURATION_FILE = 'config.yml';
exports.MIN_HTTP_TIMEOUT = 3000;
exports.HUBSPOT_ACCOUNT_TYPES = {
    DEVELOPMENT_SANDBOX: 'DEVELOPMENT_SANDBOX',
    DEVELOPER_TEST: 'DEVELOPER_TEST',
    APP_DEVELOPER: 'APP_DEVELOPER',
    STANDARD_SANDBOX: 'STANDARD_SANDBOX',
    STANDARD: 'STANDARD',
};
exports.HUBSPOT_ACCOUNT_TYPE_STRINGS = {
    DEVELOPMENT_SANDBOX: (0, lang_1.i18n)('lib.accountTypes.developmentSandbox'),
    STANDARD_SANDBOX: (0, lang_1.i18n)('lib.accountTypes.standardSandbox'),
    DEVELOPER_TEST: (0, lang_1.i18n)('lib.accountTypes.developerTest'),
    APP_DEVELOPER: (0, lang_1.i18n)('lib.accountTypes.appDeveloper'),
    STANDARD: (0, lang_1.i18n)('lib.accountTypes.standard'),
};
