export declare const DEFAULT_HUBSPOT_CONFIG_YAML_FILE_NAME = "hubspot.config.yml";
export declare const HUBSPOT_CONFIGURATION_FOLDER = ".hubspot";
export declare const HUBSPOT_CONFIGURATION_FILE = "config.yml";
export declare const MIN_HTTP_TIMEOUT = 3000;
export declare const HUBSPOT_ACCOUNT_TYPES: {
    readonly DEVELOPMENT_SANDBOX: "DEVELOPMENT_SANDBOX";
    readonly DEVELOPER_TEST: "DEVELOPER_TEST";
    readonly APP_DEVELOPER: "APP_DEVELOPER";
    readonly STANDARD_SANDBOX: "STANDARD_SANDBOX";
    readonly STANDARD: "STANDARD";
};
export declare const HUBSPOT_ACCOUNT_TYPE_STRINGS: {
    readonly DEVELOPMENT_SANDBOX: string;
    readonly STANDARD_SANDBOX: string;
    readonly DEVELOPER_TEST: string;
    readonly APP_DEVELOPER: string;
    readonly STANDARD: string;
};
