export declare const ALLOWED_EXTENSIONS: Set<string>;
export declare const JSR_ALLOWED_EXTENSIONS: Set<string>;
export declare const HUBL_EXTENSIONS: Set<string>;
export declare const MODULE_EXTENSION = "module";
export declare const FUNCTIONS_EXTENSION = "functions";
export declare const FOLDER_DOT_EXTENSIONS: string[];
