export declare const MIN_PORT_NUMBER = 1024;
export declare const MAX_PORT_NUMBER = 65535;
export declare const PORT_MANAGER_SERVER_PORT = 8080;
