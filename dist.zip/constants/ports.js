"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PORT_MANAGER_SERVER_PORT = exports.MAX_PORT_NUMBER = exports.MIN_PORT_NUMBER = void 0;
exports.MIN_PORT_NUMBER = 1024;
exports.MAX_PORT_NUMBER = 65535;
exports.PORT_MANAGER_SERVER_PORT = 8080;
