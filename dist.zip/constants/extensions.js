"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.FOLDER_DOT_EXTENSIONS = exports.FUNCTIONS_EXTENSION = exports.MODULE_EXTENSION = exports.HUBL_EXTENSIONS = exports.JSR_ALLOWED_EXTENSIONS = exports.ALLOWED_EXTENSIONS = void 0;
exports.ALLOWED_EXTENSIONS = new Set([
    'css',
    'js',
    'json',
    'html',
    'txt',
    'md',
    'jpg',
    'jpeg',
    'png',
    'gif',
    'map',
    'svg',
    'eot',
    'otf',
    'ttf',
    'woff',
    'woff2',
    'graphql',
]);
exports.JSR_ALLOWED_EXTENSIONS = new Set(['jsx', 'tsx', 'ts']);
exports.HUBL_EXTENSIONS = new Set(['css', 'html', 'js']);
exports.MODULE_EXTENSION = 'module';
exports.FUNCTIONS_EXTENSION = 'functions';
exports.FOLDER_DOT_EXTENSIONS = [exports.FUNCTIONS_EXTENSION, exports.MODULE_EXTENSION];
