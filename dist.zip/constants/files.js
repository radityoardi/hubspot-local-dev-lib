"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.FILE_TYPES = exports.FILE_UPLOAD_RESULT_TYPES = exports.DEFAULT_MODE = exports.MODE = exports.STAT_TYPES = void 0;
exports.STAT_TYPES = {
    FILE: 'file',
    SYMBOLIC_LINK: 'symlink',
    DIRECTORY: 'dir',
};
exports.MODE = {
    draft: 'draft',
    publish: 'publish',
};
exports.DEFAULT_MODE = exports.MODE.publish;
exports.FILE_UPLOAD_RESULT_TYPES = {
    SUCCESS: 'SUCCESS',
    FAILURE: 'FAILURE',
};
exports.FILE_TYPES = {
    other: 'otherFiles',
    module: 'moduleFiles',
    cssAndJs: 'cssAndJsFiles',
    template: 'templateFiles',
    json: 'jsonFiles',
};
