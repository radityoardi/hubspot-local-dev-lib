"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SANDBOX_TIMEOUT = exports.HTTP_METHOD_PREPOSITIONS = exports.HTTP_METHOD_VERBS = void 0;
exports.HTTP_METHOD_VERBS = {
    delete: 'delete',
    get: 'request',
    patch: 'update',
    post: 'post',
    put: 'update',
};
exports.HTTP_METHOD_PREPOSITIONS = {
    delete: 'of',
    get: 'for',
    patch: 'to',
    post: 'to',
    put: 'to',
};
exports.SANDBOX_TIMEOUT = 60000;
