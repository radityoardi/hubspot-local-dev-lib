export declare const HTTP_METHOD_VERBS: {
    readonly delete: "delete";
    readonly get: "request";
    readonly patch: "update";
    readonly post: "post";
    readonly put: "update";
};
export declare const HTTP_METHOD_PREPOSITIONS: {
    readonly delete: "of";
    readonly get: "for";
    readonly patch: "to";
    readonly post: "to";
    readonly put: "to";
};
export declare const SANDBOX_TIMEOUT = 60000;
