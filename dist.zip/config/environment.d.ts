import { CLIConfig_NEW } from '../types/Config';
export declare function loadConfigFromEnvironment(): CLIConfig_NEW | null;
