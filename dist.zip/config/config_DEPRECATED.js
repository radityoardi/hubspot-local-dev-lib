"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.isConfigFlagEnabled = exports.loadConfigFromEnvironment = exports.deleteConfigFile = exports.deleteEmptyConfigFile = exports.createEmptyConfigFile = exports.deleteAccount = exports.renameAccount = exports.updateAllowUsageTracking = exports.updateHttpTimeout = exports.updateDefaultMode = exports.updateDefaultAccount = exports.updateAccountConfig = exports.removeSandboxAccountFromConfig = exports.getAccountId = exports.getAccountConfig = exports.getAccountType = exports.getEnv = exports.findConfig = exports.getAndLoadConfigIfNeeded = exports.isTrackingAllowed = exports.loadConfig = exports.writeConfig = exports.getOrderedConfig = exports.getOrderedAccount = exports.accountNameExistsInConfig = exports.validateConfig = exports.getConfigPath = exports.setConfigPath = exports.getConfigAccountId = exports.getConfigDefaultAccount = exports.getConfigAccounts = exports.setConfig = exports.getConfig = void 0;
const fs_extra_1 = __importDefault(require("fs-extra"));
const js_yaml_1 = __importDefault(require("js-yaml"));
const findup_sync_1 = __importDefault(require("findup-sync"));
const path_1 = require("../lib/path");
const config_1 = require("../constants/config");
const environments_1 = require("../constants/environments");
const auth_1 = require("../constants/auth");
const files_1 = require("../constants/files");
const environment_1 = require("../lib/environment");
const logger_1 = require("../lib/logger");
const git_1 = require("../utils/git");
const errors_DEPRECATED_1 = require("../errors/errors_DEPRECATED");
const ALL_MODES = Object.values(files_1.MODE);
let _config;
let _configPath;
let environmentVariableConfigLoaded = false;
const commaSeparatedValues = (arr, conjunction = 'and', ifempty = '') => {
    const l = arr.length;
    if (!l)
        return ifempty;
    if (l < 2)
        return arr[0];
    if (l < 3)
        return arr.join(` ${conjunction} `);
    arr = arr.slice();
    arr[l - 1] = `${conjunction} ${arr[l - 1]}`;
    return arr.join(', ');
};
const getConfig = () => _config;
exports.getConfig = getConfig;
function setConfig(updatedConfig) {
    _config = updatedConfig || null;
    return _config;
}
exports.setConfig = setConfig;
function getConfigAccounts(config) {
    const __config = config || (0, exports.getConfig)();
    if (!__config)
        return;
    return __config.portals;
}
exports.getConfigAccounts = getConfigAccounts;
function getConfigDefaultAccount(config) {
    const __config = config || (0, exports.getConfig)();
    if (!__config)
        return;
    return __config.defaultPortal;
}
exports.getConfigDefaultAccount = getConfigDefaultAccount;
function getConfigAccountId(account) {
    if (!account)
        return;
    return account.portalId;
}
exports.getConfigAccountId = getConfigAccountId;
function setConfigPath(path) {
    return (_configPath = path);
}
exports.setConfigPath = setConfigPath;
function getConfigPath(path) {
    return path || (configFileExists() && _configPath) || findConfig((0, path_1.getCwd)());
}
exports.getConfigPath = getConfigPath;
function validateConfig() {
    const config = (0, exports.getConfig)();
    if (!config) {
        logger_1.logger.error('No config was found');
        return false;
    }
    const accounts = getConfigAccounts();
    if (!Array.isArray(accounts)) {
        logger_1.logger.error('config.portals[] is not defined');
        return false;
    }
    const accountIdsHash = {};
    const accountNamesHash = {};
    return accounts.every(cfg => {
        if (!cfg) {
            logger_1.logger.error('config.portals[] has an empty entry');
            return false;
        }
        const accountId = getConfigAccountId(cfg);
        if (!accountId) {
            logger_1.logger.error('config.portals[] has an entry missing portalId');
            return false;
        }
        if (accountIdsHash[accountId]) {
            logger_1.logger.error(`config.portals[] has multiple entries with portalId=${accountId}`);
            return false;
        }
        if (cfg.name) {
            if (accountNamesHash[cfg.name]) {
                logger_1.logger.error(`config.name has multiple entries with portalId=${accountId}`);
                return false;
            }
            if (/\s+/.test(cfg.name)) {
                logger_1.logger.error(`config.name '${cfg.name}' cannot contain spaces`);
                return false;
            }
            accountNamesHash[cfg.name] = cfg;
        }
        if (!cfg.accountType) {
            updateAccountConfig({
                ...cfg,
                portalId: accountId,
                accountType: getAccountType(undefined, cfg.sandboxAccountType),
            });
            writeConfig();
        }
        accountIdsHash[accountId] = cfg;
        return true;
    });
}
exports.validateConfig = validateConfig;
function accountNameExistsInConfig(name) {
    const config = (0, exports.getConfig)();
    const accounts = getConfigAccounts();
    if (!config || !Array.isArray(accounts)) {
        return false;
    }
    return accounts.some(cfg => cfg.name && cfg.name === name);
}
exports.accountNameExistsInConfig = accountNameExistsInConfig;
function getOrderedAccount(unorderedAccount) {
    const { name, portalId, env, authType, ...rest } = unorderedAccount;
    return {
        name,
        ...(portalId && { portalId }),
        env,
        authType,
        ...rest,
    };
}
exports.getOrderedAccount = getOrderedAccount;
function getOrderedConfig(unorderedConfig) {
    const { defaultPortal, defaultMode, httpTimeout, allowUsageTracking, portals, ...rest } = unorderedConfig;
    return {
        ...(defaultPortal && { defaultPortal }),
        defaultMode,
        httpTimeout,
        allowUsageTracking,
        ...rest,
        portals: portals.map(getOrderedAccount),
    };
}
exports.getOrderedConfig = getOrderedConfig;
function writeConfig(options = {}) {
    if (environmentVariableConfigLoaded) {
        return;
    }
    let source;
    try {
        source =
            typeof options.source === 'string'
                ? options.source
                : js_yaml_1.default.dump(JSON.parse(JSON.stringify(getOrderedConfig((0, exports.getConfig)()), null, 2)));
    }
    catch (err) {
        (0, errors_DEPRECATED_1.logErrorInstance)(err);
        return;
    }
    const configPath = options.path || _configPath;
    try {
        logger_1.logger.debug(`Writing current config to ${configPath}`);
        fs_extra_1.default.ensureFileSync(configPath || '');
        fs_extra_1.default.writeFileSync(configPath || '', source);
        setConfig(parseConfig(source).parsed);
    }
    catch (err) {
        (0, errors_DEPRECATED_1.logFileSystemErrorInstance)(err, {
            filepath: configPath || '',
            operation: 'write',
        });
    }
}
exports.writeConfig = writeConfig;
function readConfigFile() {
    let source;
    let error;
    if (!_configPath) {
        return { source, error };
    }
    try {
        (0, git_1.isConfigPathInGitRepo)(_configPath);
        source = fs_extra_1.default.readFileSync(_configPath);
    }
    catch (err) {
        error = err;
        logger_1.logger.error('Config file could not be read "%s"', _configPath);
        (0, errors_DEPRECATED_1.logFileSystemErrorInstance)(error, {
            filepath: _configPath,
            operation: 'read',
        });
    }
    return { source: source && source.toString(), error };
}
function parseConfig(configSource) {
    let parsed = undefined;
    let error = undefined;
    if (!configSource) {
        return { parsed, error };
    }
    try {
        parsed = js_yaml_1.default.load(configSource);
    }
    catch (err) {
        error = err;
        logger_1.logger.error('Config file could not be parsed "%s"', _configPath);
        (0, errors_DEPRECATED_1.logErrorInstance)(err);
    }
    return { parsed, error };
}
function loadConfigFromFile(path, options = {}) {
    setConfigPath(getConfigPath(path));
    if (!_configPath) {
        if (!options.silenceErrors) {
            logger_1.logger.error(`A ${config_1.DEFAULT_HUBSPOT_CONFIG_YAML_FILE_NAME} file could not be found. To create a new config file, use the "hs init" command.`);
        }
        else {
            logger_1.logger.debug(`A ${config_1.DEFAULT_HUBSPOT_CONFIG_YAML_FILE_NAME} file could not be found`);
        }
        return;
    }
    logger_1.logger.debug(`Reading config from ${_configPath}`);
    const { source, error: sourceError } = readConfigFile();
    if (sourceError)
        return;
    const { parsed, error: parseError } = parseConfig(source);
    if (parseError)
        return;
    setConfig(parsed);
    if (!(0, exports.getConfig)()) {
        logger_1.logger.debug('The config file was empty config');
        logger_1.logger.debug('Initializing an empty config');
        setConfig({ portals: [] });
    }
    return (0, exports.getConfig)();
}
function loadConfig(path, options = {
    useEnv: false,
}) {
    if (options.useEnv && loadEnvironmentVariableConfig(options)) {
        logger_1.logger.debug('Loaded environment variable config');
        environmentVariableConfigLoaded = true;
    }
    else {
        path && logger_1.logger.debug(`Loading config from ${path}`);
        loadConfigFromFile(path, options);
        environmentVariableConfigLoaded = false;
    }
    return (0, exports.getConfig)();
}
exports.loadConfig = loadConfig;
function isTrackingAllowed() {
    if (!configFileExists() || configFileIsBlank()) {
        return true;
    }
    const { allowUsageTracking } = getAndLoadConfigIfNeeded();
    return allowUsageTracking !== false;
}
exports.isTrackingAllowed = isTrackingAllowed;
function getAndLoadConfigIfNeeded(options = {}) {
    if (!(0, exports.getConfig)()) {
        loadConfig('', {
            silenceErrors: true,
            ...options,
        });
    }
    return (0, exports.getConfig)() || { allowUsageTracking: undefined };
}
exports.getAndLoadConfigIfNeeded = getAndLoadConfigIfNeeded;
function findConfig(directory) {
    return (0, findup_sync_1.default)([
        config_1.DEFAULT_HUBSPOT_CONFIG_YAML_FILE_NAME,
        config_1.DEFAULT_HUBSPOT_CONFIG_YAML_FILE_NAME.replace('.yml', '.yaml'),
    ], { cwd: directory });
}
exports.findConfig = findConfig;
function getEnv(nameOrId) {
    let env = environments_1.ENVIRONMENTS.PROD;
    const config = getAndLoadConfigIfNeeded();
    const accountId = getAccountId(nameOrId);
    if (accountId) {
        const accountConfig = getAccountConfig(accountId);
        if (accountConfig && accountConfig.env) {
            env = accountConfig.env;
        }
    }
    else if (config && config.env) {
        env = config.env;
    }
    return env;
}
exports.getEnv = getEnv;
// Deprecating sandboxAccountType in favor of accountType
function getAccountType(accountType, sandboxAccountType) {
    if (accountType) {
        return accountType;
    }
    if (typeof sandboxAccountType === 'string') {
        if (sandboxAccountType.toUpperCase() === 'DEVELOPER') {
            return config_1.HUBSPOT_ACCOUNT_TYPES.DEVELOPMENT_SANDBOX;
        }
        if (sandboxAccountType.toUpperCase() === 'STANDARD') {
            return config_1.HUBSPOT_ACCOUNT_TYPES.STANDARD_SANDBOX;
        }
    }
    return config_1.HUBSPOT_ACCOUNT_TYPES.STANDARD;
}
exports.getAccountType = getAccountType;
function getAccountConfig(accountId) {
    return getConfigAccounts(getAndLoadConfigIfNeeded())?.find(account => account.portalId === accountId);
}
exports.getAccountConfig = getAccountConfig;
/*
 * Returns a portalId from the config if it exists, else returns null
 */
function getAccountId(nameOrId) {
    const config = getAndLoadConfigIfNeeded();
    let name = undefined;
    let accountId = undefined;
    let account = undefined;
    function setNameOrAccountFromSuppliedValue(suppliedValue) {
        if (typeof suppliedValue === 'number') {
            accountId = suppliedValue;
        }
        else if (/^\d+$/.test(suppliedValue)) {
            accountId = parseInt(suppliedValue, 10);
        }
        else {
            name = suppliedValue;
        }
    }
    if (!nameOrId) {
        const defaultAccount = getConfigDefaultAccount(config);
        if (defaultAccount) {
            setNameOrAccountFromSuppliedValue(defaultAccount);
        }
    }
    else {
        setNameOrAccountFromSuppliedValue(nameOrId);
    }
    const accounts = getConfigAccounts(config);
    if (name && accounts) {
        account = accounts.find(p => p.name === name);
    }
    else if (accountId && accounts) {
        account = accounts.find(p => accountId === p.portalId);
    }
    if (account) {
        return account.portalId;
    }
    return undefined;
}
exports.getAccountId = getAccountId;
/**
 * @throws {Error}
 */
function removeSandboxAccountFromConfig(nameOrId) {
    const config = getAndLoadConfigIfNeeded();
    const accountId = getAccountId(nameOrId);
    let promptDefaultAccount = false;
    if (!accountId) {
        throw new Error(`Unable to find account for ${nameOrId}.`);
    }
    const accountConfig = getAccountConfig(accountId);
    const accountType = getAccountType(accountConfig?.accountType, accountConfig?.sandboxAccountType);
    const isSandboxAccount = accountType === config_1.HUBSPOT_ACCOUNT_TYPES.DEVELOPMENT_SANDBOX ||
        accountType === config_1.HUBSPOT_ACCOUNT_TYPES.STANDARD_SANDBOX;
    if (!isSandboxAccount)
        return promptDefaultAccount;
    if (config.defaultPortal === accountConfig?.name) {
        promptDefaultAccount = true;
    }
    const accounts = getConfigAccounts(config);
    if (accountConfig && accounts) {
        logger_1.logger.debug(`Deleting config for ${accountId}`);
        const index = accounts.indexOf(accountConfig);
        accounts.splice(index, 1);
    }
    writeConfig();
    return promptDefaultAccount;
}
exports.removeSandboxAccountFromConfig = removeSandboxAccountFromConfig;
/**
 * @throws {Error}
 */
function updateAccountConfig(configOptions) {
    const { accountType, apiKey, authType, clientId, clientSecret, defaultMode, environment, name, parentAccountId, personalAccessKey, portalId, sandboxAccountType, scopes, tokenInfo, } = configOptions;
    if (!portalId) {
        throw new Error('A portalId is required to update the config');
    }
    const config = getAndLoadConfigIfNeeded();
    const accountConfig = getAccountConfig(portalId);
    let auth = accountConfig && accountConfig.auth;
    if (clientId || clientSecret || scopes || tokenInfo) {
        auth = {
            ...(accountConfig ? accountConfig.auth : {}),
            clientId,
            clientSecret,
            scopes,
            tokenInfo,
        };
    }
    const env = (0, environment_1.getValidEnv)(environment ||
        (configOptions && configOptions.env) ||
        (accountConfig && accountConfig.env));
    const mode = defaultMode && defaultMode.toLowerCase();
    const nextAccountConfig = {
        ...accountConfig,
        name: name || (accountConfig && accountConfig.name),
        env,
        ...(portalId && { portalId }),
        authType,
        auth,
        accountType: getAccountType(accountType, sandboxAccountType),
        apiKey,
        defaultMode: mode && Object.hasOwn(files_1.MODE, mode) ? mode : undefined,
        personalAccessKey,
        sandboxAccountType,
        parentAccountId,
    };
    let accounts = getConfigAccounts(config);
    if (accountConfig && accounts) {
        logger_1.logger.debug(`Updating config for ${portalId}`);
        const index = accounts.indexOf(accountConfig);
        accounts[index] = nextAccountConfig;
    }
    else {
        logger_1.logger.debug(`Adding config entry for ${portalId}`);
        if (accounts) {
            accounts.push(nextAccountConfig);
        }
        else {
            accounts = [nextAccountConfig];
        }
    }
    return nextAccountConfig;
}
exports.updateAccountConfig = updateAccountConfig;
/**
 * @throws {Error}
 */
function updateDefaultAccount(defaultAccount) {
    if (!defaultAccount ||
        (typeof defaultAccount !== 'number' && typeof defaultAccount !== 'string')) {
        throw new Error(`A 'defaultPortal' with value of number or string is required to update the config`);
    }
    const config = getAndLoadConfigIfNeeded();
    config.defaultPortal = defaultAccount;
    setDefaultConfigPathIfUnset();
    writeConfig();
}
exports.updateDefaultAccount = updateDefaultAccount;
/**
 * @throws {Error}
 */
function updateDefaultMode(defaultMode) {
    if (!defaultMode || !ALL_MODES.find(m => m === defaultMode)) {
        throw new Error(`The mode ${defaultMode} is invalid. Valid values are ${commaSeparatedValues(ALL_MODES)}.`);
    }
    const config = getAndLoadConfigIfNeeded();
    config.defaultMode = defaultMode;
    setDefaultConfigPathIfUnset();
    writeConfig();
}
exports.updateDefaultMode = updateDefaultMode;
/**
 * @throws {Error}
 */
function updateHttpTimeout(timeout) {
    const parsedTimeout = parseInt(timeout);
    if (isNaN(parsedTimeout) || parsedTimeout < config_1.MIN_HTTP_TIMEOUT) {
        throw new Error(`The value ${timeout} is invalid. The value must be a number greater than ${config_1.MIN_HTTP_TIMEOUT}.`);
    }
    const config = getAndLoadConfigIfNeeded();
    config.httpTimeout = parsedTimeout;
    setDefaultConfigPathIfUnset();
    writeConfig();
}
exports.updateHttpTimeout = updateHttpTimeout;
/**
 * @throws {Error}
 */
function updateAllowUsageTracking(isEnabled) {
    if (typeof isEnabled !== 'boolean') {
        throw new Error(`Unable to update allowUsageTracking. The value ${isEnabled} is invalid. The value must be a boolean.`);
    }
    const config = getAndLoadConfigIfNeeded();
    config.allowUsageTracking = isEnabled;
    setDefaultConfigPathIfUnset();
    writeConfig();
}
exports.updateAllowUsageTracking = updateAllowUsageTracking;
/**
 * @throws {Error}
 */
async function renameAccount(currentName, newName) {
    const accountId = getAccountId(currentName);
    const accountConfigToRename = getAccountConfig(accountId);
    const defaultAccount = getConfigDefaultAccount();
    if (!accountConfigToRename) {
        throw new Error(`Cannot find account with identifier ${currentName}`);
    }
    await updateAccountConfig({
        ...accountConfigToRename,
        name: newName,
    });
    if (accountConfigToRename.name === defaultAccount) {
        updateDefaultAccount(newName);
    }
    return writeConfig();
}
exports.renameAccount = renameAccount;
/**
 * @throws {Error}
 */
async function deleteAccount(accountName) {
    const config = getAndLoadConfigIfNeeded();
    const accounts = getConfigAccounts(config);
    const accountIdToDelete = getAccountId(accountName);
    if (!accountIdToDelete || !accounts) {
        throw new Error(`Cannot find account with identifier ${accountName}`);
    }
    setConfig({
        ...config,
        defaultPortal: config.defaultPortal === accountName ||
            config.defaultPortal === accountIdToDelete
            ? undefined
            : config.defaultPortal,
        portals: accounts.filter(account => account.portalId !== accountIdToDelete),
    });
    return writeConfig();
}
exports.deleteAccount = deleteAccount;
function setDefaultConfigPathIfUnset() {
    if (!_configPath) {
        setDefaultConfigPath();
    }
}
function setDefaultConfigPath() {
    setConfigPath(`${(0, path_1.getCwd)()}/${config_1.DEFAULT_HUBSPOT_CONFIG_YAML_FILE_NAME}`);
}
function configFileExists() {
    return Boolean(_configPath && fs_extra_1.default.existsSync(_configPath));
}
function configFileIsBlank() {
    return Boolean(_configPath && fs_extra_1.default.readFileSync(_configPath).length === 0);
}
function createEmptyConfigFile({ path } = {}) {
    if (!path) {
        setDefaultConfigPathIfUnset();
        if (configFileExists()) {
            return;
        }
    }
    else {
        setConfigPath(path);
    }
    writeConfig({ source: '', path });
}
exports.createEmptyConfigFile = createEmptyConfigFile;
function deleteEmptyConfigFile() {
    configFileExists() && configFileIsBlank() && fs_extra_1.default.unlinkSync(_configPath || '');
}
exports.deleteEmptyConfigFile = deleteEmptyConfigFile;
function deleteConfigFile() {
    configFileExists() && fs_extra_1.default.unlinkSync(_configPath || '');
}
exports.deleteConfigFile = deleteConfigFile;
function getConfigVariablesFromEnv() {
    const env = process.env;
    return {
        apiKey: env[environments_1.ENVIRONMENT_VARIABLES.HUBSPOT_API_KEY],
        clientId: env[environments_1.ENVIRONMENT_VARIABLES.HUBSPOT_CLIENT_ID],
        clientSecret: env[environments_1.ENVIRONMENT_VARIABLES.HUBSPOT_CLIENT_SECRET],
        personalAccessKey: env[environments_1.ENVIRONMENT_VARIABLES.HUBSPOT_PERSONAL_ACCESS_KEY],
        portalId: parseInt(env[environments_1.ENVIRONMENT_VARIABLES.HUBSPOT_PORTAL_ID] || '', 10),
        refreshToken: env[environments_1.ENVIRONMENT_VARIABLES.HUBSPOT_REFRESH_TOKEN],
        httpTimeout: env[environments_1.ENVIRONMENT_VARIABLES.HTTP_TIMEOUT]
            ? parseInt(env[environments_1.ENVIRONMENT_VARIABLES.HTTP_TIMEOUT])
            : undefined,
        env: (0, environment_1.getValidEnv)(env[environments_1.ENVIRONMENT_VARIABLES.HUBSPOT_ENVIRONMENT]),
    };
}
function generatePersonalAccessKeyConfig(portalId, personalAccessKey, env, httpTimeout) {
    return {
        portals: [
            {
                authType: auth_1.PERSONAL_ACCESS_KEY_AUTH_METHOD.value,
                portalId,
                personalAccessKey,
                env,
            },
        ],
        httpTimeout,
    };
}
function generateOauthConfig(portalId, clientId, clientSecret, refreshToken, scopes, env, httpTimeout) {
    return {
        portals: [
            {
                authType: auth_1.OAUTH_AUTH_METHOD.value,
                portalId,
                auth: {
                    clientId,
                    clientSecret,
                    scopes,
                    tokenInfo: {
                        refreshToken,
                    },
                },
                env,
            },
        ],
        httpTimeout,
    };
}
function generateApiKeyConfig(portalId, apiKey, env) {
    return {
        portals: [
            {
                authType: auth_1.API_KEY_AUTH_METHOD.value,
                portalId,
                apiKey,
                env,
            },
        ],
    };
}
function loadConfigFromEnvironment({ useEnv = false, } = {}) {
    const { apiKey, clientId, clientSecret, personalAccessKey, portalId, refreshToken, env, httpTimeout, } = getConfigVariablesFromEnv();
    const unableToLoadEnvConfigError = 'Unable to load config from environment variables.';
    if (!portalId) {
        useEnv && logger_1.logger.error(unableToLoadEnvConfigError);
        return;
    }
    if (httpTimeout && httpTimeout < config_1.MIN_HTTP_TIMEOUT) {
        throw new Error(`The HTTP timeout value ${httpTimeout} is invalid. The value must be a number greater than ${config_1.MIN_HTTP_TIMEOUT}.`);
    }
    if (personalAccessKey) {
        return generatePersonalAccessKeyConfig(portalId, personalAccessKey, env, httpTimeout);
    }
    else if (clientId && clientSecret && refreshToken) {
        return generateOauthConfig(portalId, clientId, clientSecret, refreshToken, auth_1.OAUTH_SCOPES.map(scope => scope.value), env, httpTimeout);
    }
    else if (apiKey) {
        return generateApiKeyConfig(portalId, apiKey, env);
    }
    else {
        useEnv && logger_1.logger.error(unableToLoadEnvConfigError);
        return;
    }
}
exports.loadConfigFromEnvironment = loadConfigFromEnvironment;
function loadEnvironmentVariableConfig(options) {
    const envConfig = loadConfigFromEnvironment(options);
    if (!envConfig) {
        return null;
    }
    const { portalId } = getConfigVariablesFromEnv();
    logger_1.logger.debug(`Loaded config from environment variables for account ${portalId}`);
    return setConfig(envConfig);
}
function isConfigFlagEnabled(flag) {
    if (!configFileExists() || configFileIsBlank()) {
        return false;
    }
    const config = getAndLoadConfigIfNeeded();
    return Boolean(config[flag] || false);
}
exports.isConfigFlagEnabled = isConfigFlagEnabled;
