"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.loadConfigFromEnvironment = void 0;
const logger_1 = require("../lib/logger");
const environments_1 = require("../constants/environments");
const auth_1 = require("../constants/auth");
const configUtils_1 = require("./configUtils");
const environment_1 = require("../lib/environment");
const lang_1 = require("../utils/lang");
const i18nKey = 'config.environment';
function getConfigVariablesFromEnv() {
    const env = process.env;
    return {
        apiKey: env[environments_1.ENVIRONMENT_VARIABLES.HUBSPOT_API_KEY],
        clientId: env[environments_1.ENVIRONMENT_VARIABLES.HUBSPOT_CLIENT_ID],
        clientSecret: env[environments_1.ENVIRONMENT_VARIABLES.HUBSPOT_CLIENT_SECRET],
        personalAccessKey: env[environments_1.ENVIRONMENT_VARIABLES.HUBSPOT_PERSONAL_ACCESS_KEY],
        accountId: parseInt(env[environments_1.ENVIRONMENT_VARIABLES.HUBSPOT_ACCOUNT_ID], 10),
        refreshToken: env[environments_1.ENVIRONMENT_VARIABLES.HUBSPOT_REFRESH_TOKEN],
        env: (0, environment_1.getValidEnv)(env[environments_1.ENVIRONMENT_VARIABLES.HUBSPOT_ENVIRONMENT]),
    };
}
function loadConfigFromEnvironment() {
    const { apiKey, clientId, clientSecret, personalAccessKey, accountId, refreshToken, env, } = getConfigVariablesFromEnv();
    if (!accountId) {
        logger_1.logger.debug((0, lang_1.i18n)(`${i18nKey}.loadConfig.missingAccountId`));
        return null;
    }
    if (!env) {
        logger_1.logger.debug((0, lang_1.i18n)(`${i18nKey}.loadConfig.missingEnv`));
        return null;
    }
    if (personalAccessKey) {
        return (0, configUtils_1.generateConfig)(auth_1.PERSONAL_ACCESS_KEY_AUTH_METHOD.value, {
            accountId,
            personalAccessKey,
            env,
        });
    }
    else if (clientId && clientSecret && refreshToken) {
        return (0, configUtils_1.generateConfig)(auth_1.OAUTH_AUTH_METHOD.value, {
            accountId,
            clientId,
            clientSecret,
            refreshToken,
            scopes: auth_1.OAUTH_SCOPES.map((scope) => scope.value),
            env,
        });
    }
    else if (apiKey) {
        return (0, configUtils_1.generateConfig)(auth_1.API_KEY_AUTH_METHOD.value, {
            accountId,
            apiKey,
            env,
        });
    }
    logger_1.logger.debug((0, lang_1.i18n)(`${i18nKey}.loadConfig.unknownAuthType`));
    return null;
}
exports.loadConfigFromEnvironment = loadConfigFromEnvironment;
