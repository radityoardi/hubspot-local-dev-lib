import { CLIConfig_NEW, Environment } from '../types/Config';
import { CLIAccount_NEW, FlatAccountFields_NEW, AccountType } from '../types/Accounts';
import { CLIOptions } from '../types/CLIOptions';
declare class _CLIConfiguration {
    options: CLIOptions;
    useEnvConfig: boolean;
    config: CLIConfig_NEW | null;
    active: boolean;
    constructor();
    setActive(isActive: boolean): void;
    isActive(): boolean;
    init(options?: CLIOptions): CLIConfig_NEW | null;
    load(): CLIConfig_NEW | null;
    configIsEmpty(): boolean;
    delete(): void;
    write(updatedConfig?: CLIConfig_NEW): CLIConfig_NEW | null;
    validate(): boolean;
    getAccount(nameOrId: string | number | undefined): CLIAccount_NEW | null;
    isConfigFlagEnabled(flag: keyof CLIConfig_NEW, defaultValue?: boolean): boolean;
    getAccountId(nameOrId?: string | number): number | null;
    getDefaultAccount(): string | number | null;
    getResolvedDefaultAccountForCWD(nameOrId: string | number): CLIAccount_NEW | null;
    getConfigAccountIndex(accountId: number): number;
    getConfigForAccount(accountId?: number): CLIAccount_NEW | null;
    isAccountInConfig(nameOrId: string | number): boolean;
    getAndLoadConfigIfNeeded(options?: CLIOptions): CLIConfig_NEW;
    getEnv(nameOrId?: string | number): Environment;
    getAccountType(accountType?: AccountType, sandboxAccountType?: string | null): AccountType;
    /**
     * @throws {Error}
     */
    updateAccount(updatedAccountFields: Partial<FlatAccountFields_NEW>, writeUpdate?: boolean): FlatAccountFields_NEW | null;
    /**
     * @throws {Error}
     */
    updateDefaultAccount(defaultAccount: string | number): CLIConfig_NEW | null;
    /**
     * @throws {Error}
     */
    renameAccount(currentName: string, newName: string): void;
    /**
     * @throws {Error}
     * TODO: this does not account for the special handling of sandbox account deletes
     */
    removeAccountFromConfig(nameOrId: string | number): boolean;
    /**
     * @throws {Error}
     */
    updateDefaultMode(defaultMode: string): CLIConfig_NEW | null;
    /**
     * @throws {Error}
     */
    updateHttpTimeout(timeout: string): CLIConfig_NEW | null;
    /**
     * @throws {Error}
     */
    updateAllowUsageTracking(isEnabled: boolean): CLIConfig_NEW | null;
    isTrackingAllowed(): boolean;
}
export declare const CLIConfiguration: _CLIConfiguration;
export {};
