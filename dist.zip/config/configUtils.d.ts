import { CLIConfig_NEW } from '../types/Config';
import { AuthType, CLIAccount_NEW, PersonalAccessKeyOptions, OAuthOptions, APIKeyOptions } from '../types/Accounts';
export declare function getOrderedAccount(unorderedAccount: CLIAccount_NEW): CLIAccount_NEW;
export declare function getOrderedConfig(unorderedConfig: CLIConfig_NEW): CLIConfig_NEW;
export declare function generateConfig(type: AuthType, options: PersonalAccessKeyOptions | OAuthOptions | APIKeyOptions): CLIConfig_NEW | null;
