import { CLIConfig_DEPRECATED, Environment } from '../types/Config';
import { AccountType, CLIAccount_DEPRECATED, FlatAccountFields_DEPRECATED, UpdateAccountConfigOptions } from '../types/Accounts';
import { Mode } from '../types/Files';
import { CLIOptions, WriteConfigOptions } from '../types/CLIOptions';
export declare const getConfig: () => CLIConfig_DEPRECATED | null;
export declare function setConfig(updatedConfig?: CLIConfig_DEPRECATED): CLIConfig_DEPRECATED | null;
export declare function getConfigAccounts(config?: CLIConfig_DEPRECATED): Array<CLIAccount_DEPRECATED> | undefined;
export declare function getConfigDefaultAccount(config?: CLIConfig_DEPRECATED): string | number | undefined;
export declare function getConfigAccountId(account: CLIAccount_DEPRECATED): number | undefined;
export declare function setConfigPath(path: string | null): string | null;
export declare function getConfigPath(path?: string | null): string | null;
export declare function validateConfig(): boolean;
export declare function accountNameExistsInConfig(name: string): boolean;
export declare function getOrderedAccount(unorderedAccount: CLIAccount_DEPRECATED): CLIAccount_DEPRECATED;
export declare function getOrderedConfig(unorderedConfig: CLIConfig_DEPRECATED): {
    portals: CLIAccount_DEPRECATED[];
    env?: Environment | undefined;
    httpUseLocalhost?: boolean | undefined;
    defaultMode: string | undefined;
    httpTimeout: number | undefined;
    allowUsageTracking: boolean | undefined;
    defaultPortal?: string | number | undefined;
};
export declare function writeConfig(options?: WriteConfigOptions): void;
export declare function loadConfig(path?: string, options?: CLIOptions): CLIConfig_DEPRECATED | null;
export declare function isTrackingAllowed(): boolean;
export declare function getAndLoadConfigIfNeeded(options?: {}): Partial<CLIConfig_DEPRECATED>;
export declare function findConfig(directory: string): string | null;
export declare function getEnv(nameOrId?: string | number): Environment;
export declare function getAccountType(accountType?: AccountType, sandboxAccountType?: string | null): AccountType;
export declare function getAccountConfig(accountId: number | undefined): CLIAccount_DEPRECATED | undefined;
export declare function getAccountId(nameOrId?: string | number): number | undefined;
/**
 * @throws {Error}
 */
export declare function removeSandboxAccountFromConfig(nameOrId: string | number): boolean;
/**
 * @throws {Error}
 */
export declare function updateAccountConfig(configOptions: UpdateAccountConfigOptions): FlatAccountFields_DEPRECATED;
/**
 * @throws {Error}
 */
export declare function updateDefaultAccount(defaultAccount: string | number): void;
/**
 * @throws {Error}
 */
export declare function updateDefaultMode(defaultMode: Mode): void;
/**
 * @throws {Error}
 */
export declare function updateHttpTimeout(timeout: string): void;
/**
 * @throws {Error}
 */
export declare function updateAllowUsageTracking(isEnabled: boolean): void;
/**
 * @throws {Error}
 */
export declare function renameAccount(currentName: string, newName: string): Promise<void>;
/**
 * @throws {Error}
 */
export declare function deleteAccount(accountName: string): Promise<void>;
export declare function createEmptyConfigFile({ path }?: {
    path?: string;
}): void;
export declare function deleteEmptyConfigFile(): void;
export declare function deleteConfigFile(): void;
export declare function loadConfigFromEnvironment({ useEnv, }?: {
    useEnv?: boolean;
}): {
    portals: Array<CLIAccount_DEPRECATED>;
} | undefined;
export declare function isConfigFlagEnabled(flag: keyof CLIConfig_DEPRECATED): boolean;
