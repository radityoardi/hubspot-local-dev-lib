"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.updateDefaultMode = exports.findConfig = exports.setConfigPath = exports.setConfig = exports.getOrderedConfig = exports.getOrderedAccount = exports.getConfigAccountId = exports.getConfigDefaultAccount = exports.getConfigAccounts = exports.getAccountType = exports.getEnv = exports.isTrackingAllowed = exports.isConfigFlagEnabled = exports.deleteConfigFile = exports.updateAllowUsageTracking = exports.updateHttpTimeout = exports.deleteAccount = exports.removeSandboxAccountFromConfig = exports.getAccountId = exports.renameAccount = exports.updateDefaultAccount = exports.updateAccountConfig = exports.accountNameExistsInConfig = exports.getAccountConfig = exports.getConfigPath = exports.writeConfig = exports.getConfig = exports.deleteEmptyConfigFile = exports.createEmptyConfigFile = exports.loadConfigFromEnvironment = exports.validateConfig = exports.getAndLoadConfigIfNeeded = exports.loadConfig = void 0;
const config_DEPRECATED = __importStar(require("./config_DEPRECATED"));
const CLIConfiguration_1 = require("./CLIConfiguration");
const configFile_1 = require("./configFile");
const getAccountIdentifier_1 = require("../utils/getAccountIdentifier");
// Use new config if it exists
function loadConfig(path, options = {}) {
    // Attempt to load the root config
    if ((0, configFile_1.configFileExists)()) {
        return CLIConfiguration_1.CLIConfiguration.init(options);
    }
    return config_DEPRECATED.loadConfig(path, options);
}
exports.loadConfig = loadConfig;
function getAndLoadConfigIfNeeded(options) {
    if (CLIConfiguration_1.CLIConfiguration.isActive()) {
        return CLIConfiguration_1.CLIConfiguration.config;
    }
    return config_DEPRECATED.getAndLoadConfigIfNeeded(options);
}
exports.getAndLoadConfigIfNeeded = getAndLoadConfigIfNeeded;
function validateConfig() {
    if (CLIConfiguration_1.CLIConfiguration.isActive()) {
        return CLIConfiguration_1.CLIConfiguration.validate();
    }
    return config_DEPRECATED.validateConfig();
}
exports.validateConfig = validateConfig;
function loadConfigFromEnvironment() {
    if (CLIConfiguration_1.CLIConfiguration.isActive()) {
        return CLIConfiguration_1.CLIConfiguration.useEnvConfig;
    }
    return Boolean(config_DEPRECATED.loadConfigFromEnvironment());
}
exports.loadConfigFromEnvironment = loadConfigFromEnvironment;
function createEmptyConfigFile(options = {}, useRootConfig = false) {
    if (useRootConfig) {
        CLIConfiguration_1.CLIConfiguration.write({ accounts: [] });
    }
    else {
        return config_DEPRECATED.createEmptyConfigFile(options);
    }
}
exports.createEmptyConfigFile = createEmptyConfigFile;
function deleteEmptyConfigFile() {
    if (CLIConfiguration_1.CLIConfiguration.isActive()) {
        return CLIConfiguration_1.CLIConfiguration.delete();
    }
    return config_DEPRECATED.deleteEmptyConfigFile();
}
exports.deleteEmptyConfigFile = deleteEmptyConfigFile;
function getConfig() {
    if (CLIConfiguration_1.CLIConfiguration.isActive()) {
        return CLIConfiguration_1.CLIConfiguration.config;
    }
    return config_DEPRECATED.getConfig();
}
exports.getConfig = getConfig;
function writeConfig(options = {}) {
    if (CLIConfiguration_1.CLIConfiguration.isActive()) {
        const config = options.source
            ? JSON.parse(options.source)
            : undefined;
        CLIConfiguration_1.CLIConfiguration.write(config);
    }
    else {
        config_DEPRECATED.writeConfig(options);
    }
}
exports.writeConfig = writeConfig;
function getConfigPath(path) {
    if (CLIConfiguration_1.CLIConfiguration.isActive()) {
        return (0, configFile_1.getConfigFilePath)();
    }
    return config_DEPRECATED.getConfigPath(path);
}
exports.getConfigPath = getConfigPath;
function getAccountConfig(accountId) {
    if (CLIConfiguration_1.CLIConfiguration.isActive()) {
        return CLIConfiguration_1.CLIConfiguration.getConfigForAccount(accountId);
    }
    return config_DEPRECATED.getAccountConfig(accountId) || null;
}
exports.getAccountConfig = getAccountConfig;
function accountNameExistsInConfig(name) {
    if (CLIConfiguration_1.CLIConfiguration.isActive()) {
        return CLIConfiguration_1.CLIConfiguration.isAccountInConfig(name);
    }
    return config_DEPRECATED.accountNameExistsInConfig(name);
}
exports.accountNameExistsInConfig = accountNameExistsInConfig;
function updateAccountConfig(configOptions) {
    const accountIdentifier = (0, getAccountIdentifier_1.getAccountIdentifier)(configOptions);
    if (CLIConfiguration_1.CLIConfiguration.isActive()) {
        return CLIConfiguration_1.CLIConfiguration.updateAccount({
            ...configOptions,
            accountId: accountIdentifier,
        });
    }
    return config_DEPRECATED.updateAccountConfig({
        ...configOptions,
        portalId: accountIdentifier,
    });
}
exports.updateAccountConfig = updateAccountConfig;
function updateDefaultAccount(nameOrId) {
    if (CLIConfiguration_1.CLIConfiguration.isActive()) {
        CLIConfiguration_1.CLIConfiguration.updateDefaultAccount(nameOrId);
    }
    else {
        config_DEPRECATED.updateDefaultAccount(nameOrId);
    }
}
exports.updateDefaultAccount = updateDefaultAccount;
async function renameAccount(currentName, newName) {
    if (CLIConfiguration_1.CLIConfiguration.isActive()) {
        CLIConfiguration_1.CLIConfiguration.renameAccount(currentName, newName);
    }
    else {
        config_DEPRECATED.renameAccount(currentName, newName);
    }
}
exports.renameAccount = renameAccount;
function getAccountId(nameOrId) {
    if (CLIConfiguration_1.CLIConfiguration.isActive()) {
        return CLIConfiguration_1.CLIConfiguration.getAccountId(nameOrId);
    }
    return config_DEPRECATED.getAccountId(nameOrId) || null;
}
exports.getAccountId = getAccountId;
function removeSandboxAccountFromConfig(nameOrId) {
    if (CLIConfiguration_1.CLIConfiguration.isActive()) {
        return CLIConfiguration_1.CLIConfiguration.removeAccountFromConfig(nameOrId);
    }
    return config_DEPRECATED.removeSandboxAccountFromConfig(nameOrId);
}
exports.removeSandboxAccountFromConfig = removeSandboxAccountFromConfig;
async function deleteAccount(accountName) {
    if (CLIConfiguration_1.CLIConfiguration.isActive()) {
        CLIConfiguration_1.CLIConfiguration.removeAccountFromConfig(accountName);
    }
    else {
        config_DEPRECATED.deleteAccount(accountName);
    }
}
exports.deleteAccount = deleteAccount;
function updateHttpTimeout(timeout) {
    if (CLIConfiguration_1.CLIConfiguration.isActive()) {
        CLIConfiguration_1.CLIConfiguration.updateHttpTimeout(timeout);
    }
    else {
        config_DEPRECATED.updateHttpTimeout(timeout);
    }
}
exports.updateHttpTimeout = updateHttpTimeout;
function updateAllowUsageTracking(isEnabled) {
    if (CLIConfiguration_1.CLIConfiguration.isActive()) {
        CLIConfiguration_1.CLIConfiguration.updateAllowUsageTracking(isEnabled);
    }
    else {
        config_DEPRECATED.updateAllowUsageTracking(isEnabled);
    }
}
exports.updateAllowUsageTracking = updateAllowUsageTracking;
function deleteConfigFile() {
    if (CLIConfiguration_1.CLIConfiguration.isActive()) {
        (0, configFile_1.deleteConfigFile)();
    }
    else {
        config_DEPRECATED.deleteConfigFile();
    }
}
exports.deleteConfigFile = deleteConfigFile;
function isConfigFlagEnabled(flag) {
    if (CLIConfiguration_1.CLIConfiguration.isActive()) {
        return CLIConfiguration_1.CLIConfiguration.isConfigFlagEnabled(flag);
    }
    return config_DEPRECATED.isConfigFlagEnabled(flag);
}
exports.isConfigFlagEnabled = isConfigFlagEnabled;
function isTrackingAllowed() {
    if (CLIConfiguration_1.CLIConfiguration.isActive()) {
        return CLIConfiguration_1.CLIConfiguration.isTrackingAllowed();
    }
    return config_DEPRECATED.isTrackingAllowed();
}
exports.isTrackingAllowed = isTrackingAllowed;
function getEnv(nameOrId) {
    if (CLIConfiguration_1.CLIConfiguration.isActive()) {
        return CLIConfiguration_1.CLIConfiguration.getEnv(nameOrId);
    }
    return config_DEPRECATED.getEnv(nameOrId);
}
exports.getEnv = getEnv;
function getAccountType(accountType, sandboxAccountType) {
    if (CLIConfiguration_1.CLIConfiguration.isActive()) {
        return CLIConfiguration_1.CLIConfiguration.getAccountType(accountType, sandboxAccountType);
    }
    return config_DEPRECATED.getAccountType(accountType, sandboxAccountType);
}
exports.getAccountType = getAccountType;
// These functions are either not supported or have breaking changes with the new config setup
exports.getConfigAccounts = config_DEPRECATED.getConfigAccounts;
exports.getConfigDefaultAccount = config_DEPRECATED.getConfigDefaultAccount;
exports.getConfigAccountId = config_DEPRECATED.getConfigAccountId;
exports.getOrderedAccount = config_DEPRECATED.getOrderedAccount;
exports.getOrderedConfig = config_DEPRECATED.getOrderedConfig;
exports.setConfig = config_DEPRECATED.setConfig;
exports.setConfigPath = config_DEPRECATED.setConfigPath;
exports.findConfig = config_DEPRECATED.findConfig;
exports.updateDefaultMode = config_DEPRECATED.updateDefaultMode;
