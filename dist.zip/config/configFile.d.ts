import { CLIConfig_NEW } from '../types/Config';
export declare function getConfigFilePath(): string;
export declare function configFileExists(): boolean;
export declare function configFileIsBlank(): boolean;
export declare function deleteConfigFile(): void;
/**
 * @throws {Error}
 */
export declare function readConfigFile(configPath: string): string;
/**
 * @throws {Error}
 */
export declare function parseConfig(configSource: string): CLIConfig_NEW;
/**
 * @throws {Error}
 */
export declare function loadConfigFromFile(): CLIConfig_NEW | null;
/**
 * @throws {Error}
 */
export declare function writeConfigToFile(config: CLIConfig_NEW): void;
