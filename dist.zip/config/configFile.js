"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.writeConfigToFile = exports.loadConfigFromFile = exports.parseConfig = exports.readConfigFile = exports.deleteConfigFile = exports.configFileIsBlank = exports.configFileExists = exports.getConfigFilePath = void 0;
const fs_extra_1 = __importDefault(require("fs-extra"));
const path_1 = __importDefault(require("path"));
const os_1 = __importDefault(require("os"));
const js_yaml_1 = __importDefault(require("js-yaml"));
const logger_1 = require("../lib/logger");
const config_1 = require("../constants/config");
const configUtils_1 = require("./configUtils");
const lang_1 = require("../utils/lang");
const FileSystemError_1 = require("../models/FileSystemError");
const i18nKey = 'config.configFile';
function getConfigFilePath() {
    return path_1.default.join(os_1.default.homedir(), config_1.HUBSPOT_CONFIGURATION_FOLDER, config_1.HUBSPOT_CONFIGURATION_FILE);
}
exports.getConfigFilePath = getConfigFilePath;
function configFileExists() {
    const configPath = getConfigFilePath();
    return !!configPath && fs_extra_1.default.existsSync(configPath);
}
exports.configFileExists = configFileExists;
function configFileIsBlank() {
    const configPath = getConfigFilePath();
    return !!configPath && fs_extra_1.default.readFileSync(configPath).length === 0;
}
exports.configFileIsBlank = configFileIsBlank;
function deleteConfigFile() {
    const configPath = getConfigFilePath();
    fs_extra_1.default.unlinkSync(configPath);
}
exports.deleteConfigFile = deleteConfigFile;
/**
 * @throws {Error}
 */
function readConfigFile(configPath) {
    let source = '';
    try {
        source = fs_extra_1.default.readFileSync(configPath).toString();
    }
    catch (err) {
        logger_1.logger.debug((0, lang_1.i18n)(`${i18nKey}.errorReading`, { configPath }));
        throw new FileSystemError_1.FileSystemError({ cause: err }, {
            filepath: configPath,
            operation: 'read',
        });
    }
    return source;
}
exports.readConfigFile = readConfigFile;
/**
 * @throws {Error}
 */
function parseConfig(configSource) {
    let parsed;
    try {
        parsed = js_yaml_1.default.load(configSource);
    }
    catch (err) {
        throw new Error((0, lang_1.i18n)(`${i18nKey}.errors.parsing`), { cause: err });
    }
    return parsed;
}
exports.parseConfig = parseConfig;
/**
 * @throws {Error}
 */
function loadConfigFromFile() {
    const configPath = getConfigFilePath();
    if (configPath) {
        const source = readConfigFile(configPath);
        if (!source) {
            return null;
        }
        return parseConfig(source);
    }
    logger_1.logger.debug((0, lang_1.i18n)(`${i18nKey}.errorLoading`, { configPath }));
    return null;
}
exports.loadConfigFromFile = loadConfigFromFile;
/**
 * @throws {Error}
 */
function writeConfigToFile(config) {
    const source = js_yaml_1.default.dump(JSON.parse(JSON.stringify((0, configUtils_1.getOrderedConfig)(config), null, 2)));
    const configPath = getConfigFilePath();
    try {
        fs_extra_1.default.ensureFileSync(configPath);
        fs_extra_1.default.writeFileSync(configPath, source);
        logger_1.logger.debug((0, lang_1.i18n)(`${i18nKey}.writeSuccess`, { configPath }));
    }
    catch (err) {
        throw new FileSystemError_1.FileSystemError({ cause: err }, {
            filepath: configPath,
            operation: 'write',
        });
    }
}
exports.writeConfigToFile = writeConfigToFile;
