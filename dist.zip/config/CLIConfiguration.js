"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CLIConfiguration = void 0;
const logger_1 = require("../lib/logger");
const environment_1 = require("./environment");
const environment_2 = require("../lib/environment");
const configFile_1 = require("./configFile");
const text_1 = require("../lib/text");
const environments_1 = require("../constants/environments");
const auth_1 = require("../constants/auth");
const config_1 = require("../constants/config");
const files_1 = require("../constants/files");
const lang_1 = require("../utils/lang");
const i18nKey = 'config.cliConfiguration';
class _CLIConfiguration {
    options;
    useEnvConfig;
    config;
    active;
    constructor() {
        this.options = {};
        this.useEnvConfig = false;
        this.config = null;
        this.active = false;
    }
    setActive(isActive) {
        this.active = isActive;
    }
    isActive() {
        return this.active;
    }
    init(options = {}) {
        this.options = options;
        this.load();
        this.setActive(true);
        return this.config;
    }
    load() {
        if (this.options.useEnv) {
            const configFromEnv = (0, environment_1.loadConfigFromEnvironment)();
            if (configFromEnv) {
                logger_1.logger.debug((0, lang_1.i18n)(`${i18nKey}.load.configFromEnv`, {
                    accountId: configFromEnv.accounts[0].accountId,
                }));
                this.useEnvConfig = true;
                this.config = configFromEnv;
            }
        }
        else {
            const configFromFile = (0, configFile_1.loadConfigFromFile)();
            logger_1.logger.debug((0, lang_1.i18n)(`${i18nKey}.load.configFromFile`));
            if (!configFromFile) {
                logger_1.logger.debug((0, lang_1.i18n)(`${i18nKey}.load.empty`));
                this.config = { accounts: [] };
            }
            this.useEnvConfig = false;
            this.config = configFromFile;
        }
        return this.config;
    }
    configIsEmpty() {
        if (!(0, configFile_1.configFileExists)() || (0, configFile_1.configFileIsBlank)()) {
            return true;
        }
        else {
            this.load();
            if (!!this.config &&
                Object.keys(this.config).length === 1 &&
                !!this.config.accounts) {
                return true;
            }
        }
        return false;
    }
    delete() {
        if (!this.useEnvConfig && this.configIsEmpty()) {
            (0, configFile_1.deleteConfigFile)();
            this.config = null;
        }
    }
    write(updatedConfig) {
        if (!this.useEnvConfig) {
            if (updatedConfig) {
                this.config = updatedConfig;
            }
            if (this.config) {
                (0, configFile_1.writeConfigToFile)(this.config);
            }
        }
        return this.config;
    }
    validate() {
        if (!this.config) {
            logger_1.logger.log((0, lang_1.i18n)(`${i18nKey}.validate.noConfig`));
            return false;
        }
        if (!Array.isArray(this.config.accounts)) {
            logger_1.logger.log((0, lang_1.i18n)(`${i18nKey}.validate.noConfigAccounts`));
            return false;
        }
        const accountIdsMap = {};
        const accountNamesMap = {};
        return this.config.accounts.every(accountConfig => {
            if (!accountConfig) {
                logger_1.logger.log((0, lang_1.i18n)(`${i18nKey}.validate.emptyAccountConfig`));
                return false;
            }
            if (!accountConfig.accountId) {
                logger_1.logger.log((0, lang_1.i18n)(`${i18nKey}.validate.noAccountId`));
                return false;
            }
            if (accountIdsMap[accountConfig.accountId]) {
                logger_1.logger.log((0, lang_1.i18n)(`${i18nKey}.validate.duplicateAccountIds`, {
                    accountId: accountConfig.accountId,
                }));
                return false;
            }
            if (accountConfig.name) {
                if (accountNamesMap[accountConfig.name]) {
                    logger_1.logger.log((0, lang_1.i18n)(`${i18nKey}.validate.duplicateAccountNames`, {
                        accountName: accountConfig.name,
                    }));
                    return false;
                }
                if (/\s+/.test(accountConfig.name)) {
                    logger_1.logger.log((0, lang_1.i18n)(`${i18nKey}.validate.nameContainsSpaces`, {
                        accountName: accountConfig.name,
                    }));
                    return false;
                }
                accountNamesMap[accountConfig.name] = true;
            }
            if (!accountConfig.accountType) {
                this.updateAccount({
                    ...accountConfig,
                    accountId: accountConfig.accountId,
                    accountType: this.getAccountType(undefined, accountConfig.sandboxAccountType),
                });
            }
            accountIdsMap[accountConfig.accountId] = true;
            return true;
        });
    }
    getAccount(nameOrId) {
        let name = null;
        let accountId = null;
        if (!this.config) {
            return null;
        }
        const nameOrIdToCheck = nameOrId ? nameOrId : this.getDefaultAccount();
        if (!nameOrIdToCheck) {
            return null;
        }
        if (typeof nameOrIdToCheck === 'number') {
            accountId = nameOrIdToCheck;
        }
        else if (/^\d+$/.test(nameOrIdToCheck)) {
            accountId = parseInt(nameOrIdToCheck, 10);
        }
        else {
            name = nameOrIdToCheck;
        }
        if (name) {
            return this.config.accounts.find(a => a.name === name) || null;
        }
        else if (accountId) {
            return this.config.accounts.find(a => accountId === a.accountId) || null;
        }
        return null;
    }
    isConfigFlagEnabled(flag, defaultValue = false) {
        if (this.config && typeof this.config[flag] !== 'undefined') {
            return Boolean(this.config[flag]);
        }
        return defaultValue;
    }
    getAccountId(nameOrId) {
        const account = this.getAccount(nameOrId);
        return account ? account.accountId : null;
    }
    getDefaultAccount() {
        return this.config && this.config.defaultAccount
            ? this.config.defaultAccount
            : null;
    }
    // TODO a util that returns the account to use, respecting the values set in
    // "defaultAccountOverrides"
    // Example "defaultAccountOverrides":
    //  - /src/brodgers/customer-project-1: customer-account1
    //  - /src/brodgers/customer-project-2: customer-account2
    // "/src/brodgers/customer-project-1" is the path to the project dir
    // "customer-account1" is the name of the account to use as the default for the specified dir
    // These defaults take precedence over the standard default account specified in the config
    getResolvedDefaultAccountForCWD(nameOrId) {
        return this.getAccount(nameOrId);
    }
    getConfigAccountIndex(accountId) {
        return this.config
            ? this.config.accounts.findIndex(account => account.accountId === accountId)
            : -1;
    }
    getConfigForAccount(accountId) {
        if (this.config) {
            this.config.accounts.find(account => account.accountId === accountId) ||
                null;
        }
        return null;
    }
    isAccountInConfig(nameOrId) {
        return (!!this.config && this.config.accounts && !!this.getAccountId(nameOrId));
    }
    getAndLoadConfigIfNeeded(options) {
        if (!this.config) {
            this.init(options);
        }
        return this.config;
    }
    getEnv(nameOrId) {
        const accountConfig = this.getAccount(nameOrId);
        if (accountConfig && accountConfig.accountId && accountConfig.env) {
            return accountConfig.env;
        }
        if (this.config && this.config.env) {
            return this.config.env;
        }
        return environments_1.ENVIRONMENTS.PROD;
    }
    // Deprecating sandboxAccountType in favor of accountType
    getAccountType(accountType, sandboxAccountType) {
        if (accountType) {
            return accountType;
        }
        if (typeof sandboxAccountType === 'string') {
            if (sandboxAccountType.toUpperCase() === 'DEVELOPER') {
                return config_1.HUBSPOT_ACCOUNT_TYPES.DEVELOPMENT_SANDBOX;
            }
            if (sandboxAccountType.toUpperCase() === 'STANDARD') {
                return config_1.HUBSPOT_ACCOUNT_TYPES.STANDARD_SANDBOX;
            }
        }
        return config_1.HUBSPOT_ACCOUNT_TYPES.STANDARD;
    }
    /*
     * Config Update Utils
     */
    /**
     * @throws {Error}
     */
    updateAccount(updatedAccountFields, writeUpdate = true) {
        const { accountId, accountType, apiKey, authType, clientId, clientSecret, defaultMode, env, name, parentAccountId, personalAccessKey, sandboxAccountType, scopes, tokenInfo, } = updatedAccountFields;
        if (!accountId) {
            throw new Error((0, lang_1.i18n)(`${i18nKey}.updateAccount.errors.accountIdRequired`));
        }
        if (!this.config) {
            logger_1.logger.debug((0, lang_1.i18n)(`${i18nKey}.updateAccount.noConfigToUpdate`));
            return null;
        }
        const currentAccountConfig = this.getAccount(accountId);
        let auth = (currentAccountConfig && currentAccountConfig.auth) || {};
        if (clientId || clientSecret || scopes || tokenInfo) {
            auth = {
                ...(currentAccountConfig ? currentAccountConfig.auth : {}),
                clientId,
                clientSecret,
                scopes,
                tokenInfo,
            };
        }
        const nextAccountConfig = {
            ...(currentAccountConfig ? currentAccountConfig : {}),
        };
        // Allow everything except for 'undefined' values to override the existing values
        function safelyApplyUpdates(fieldName, 
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        newValue) {
            if (typeof newValue !== 'undefined') {
                nextAccountConfig[fieldName] = newValue;
            }
        }
        const updatedEnv = (0, environment_2.getValidEnv)(env || (currentAccountConfig && currentAccountConfig.env));
        const updatedDefaultMode = defaultMode && defaultMode.toLowerCase();
        safelyApplyUpdates('name', name);
        safelyApplyUpdates('env', updatedEnv);
        safelyApplyUpdates('accountId', accountId);
        safelyApplyUpdates('authType', authType);
        safelyApplyUpdates('auth', auth);
        if (nextAccountConfig.authType === auth_1.API_KEY_AUTH_METHOD.value) {
            safelyApplyUpdates('apiKey', apiKey);
        }
        if (typeof updatedDefaultMode !== 'undefined') {
            // eslint-disable-next-line @typescript-eslint/no-explicit-any
            safelyApplyUpdates('defaultMode', files_1.MODE[updatedDefaultMode]);
        }
        safelyApplyUpdates('personalAccessKey', personalAccessKey);
        // Deprecating sandboxAccountType in favor of the more generic accountType
        safelyApplyUpdates('sandboxAccountType', sandboxAccountType);
        safelyApplyUpdates('accountType', this.getAccountType(accountType, sandboxAccountType));
        safelyApplyUpdates('parentAccountId', parentAccountId);
        const completedAccountConfig = nextAccountConfig;
        if (currentAccountConfig) {
            logger_1.logger.debug((0, lang_1.i18n)(`${i18nKey}.updateAccount.updating`, {
                accountId,
            }));
            const index = this.getConfigAccountIndex(accountId);
            this.config.accounts[index] = completedAccountConfig;
            logger_1.logger.debug((0, lang_1.i18n)(`${i18nKey}.updateAccount.addingConfigEntry`, {
                accountId,
            }));
            if (this.config.accounts) {
                this.config.accounts.push(completedAccountConfig);
            }
            else {
                this.config.accounts = [completedAccountConfig];
            }
        }
        if (writeUpdate) {
            this.write();
        }
        return completedAccountConfig;
    }
    /**
     * @throws {Error}
     */
    updateDefaultAccount(defaultAccount) {
        if (!this.config) {
            throw new Error((0, lang_1.i18n)(`${i18nKey}.errors.noConfigLoaded`));
        }
        if (!defaultAccount ||
            (typeof defaultAccount !== 'number' && typeof defaultAccount !== 'string')) {
            throw new Error((0, lang_1.i18n)(`${i18nKey}.updateDefaultAccount.errors.invalidInput`));
        }
        this.config.defaultAccount = defaultAccount;
        return this.write();
    }
    /**
     * @throws {Error}
     */
    renameAccount(currentName, newName) {
        if (!this.config) {
            throw new Error((0, lang_1.i18n)(`${i18nKey}.errors.noConfigLoaded`));
        }
        const accountId = this.getAccountId(currentName);
        let accountConfigToRename = null;
        if (accountId) {
            accountConfigToRename = this.getAccount(accountId);
        }
        if (!accountConfigToRename) {
            throw new Error((0, lang_1.i18n)(`${i18nKey}.renameAccount.errors.invalidName`, {
                currentName,
            }));
        }
        if (accountId) {
            this.updateAccount({ accountId, name: newName, env: this.getEnv() });
        }
        if (accountConfigToRename.name === this.getDefaultAccount()) {
            this.updateDefaultAccount(newName);
        }
    }
    /**
     * @throws {Error}
     * TODO: this does not account for the special handling of sandbox account deletes
     */
    removeAccountFromConfig(nameOrId) {
        if (!this.config) {
            throw new Error((0, lang_1.i18n)(`${i18nKey}.errors.noConfigLoaded`));
        }
        const accountId = this.getAccountId(nameOrId);
        if (!accountId) {
            throw new Error((0, lang_1.i18n)(`${i18nKey}.removeAccountFromConfig.errors.invalidId`, {
                nameOrId,
            }));
        }
        let removedAccountIsDefault = false;
        const accountConfig = this.getAccount(accountId);
        if (accountConfig) {
            logger_1.logger.debug((0, lang_1.i18n)(`${i18nKey}.removeAccountFromConfig.deleting`, { accountId }));
            const index = this.getConfigAccountIndex(accountId);
            this.config.accounts.splice(index, 1);
            if (this.getDefaultAccount() === accountConfig.name) {
                removedAccountIsDefault = true;
            }
            this.write();
        }
        return removedAccountIsDefault;
    }
    /**
     * @throws {Error}
     */
    updateDefaultMode(defaultMode) {
        if (!this.config) {
            throw new Error((0, lang_1.i18n)(`${i18nKey}.errors.noConfigLoaded`));
        }
        const ALL_MODES = Object.values(files_1.MODE);
        if (!defaultMode || !ALL_MODES.find(m => m === defaultMode)) {
            throw new Error((0, lang_1.i18n)(`${i18nKey}.updateDefaultMode.errors.invalidMode`, {
                defaultMode,
                validModes: (0, text_1.commaSeparatedValues)(ALL_MODES),
            }));
        }
        this.config.defaultMode = defaultMode;
        return this.write();
    }
    /**
     * @throws {Error}
     */
    updateHttpTimeout(timeout) {
        if (!this.config) {
            throw new Error((0, lang_1.i18n)(`${i18nKey}.errors.noConfigLoaded`));
        }
        const parsedTimeout = parseInt(timeout);
        if (isNaN(parsedTimeout) || parsedTimeout < config_1.MIN_HTTP_TIMEOUT) {
            throw new Error((0, lang_1.i18n)(`${i18nKey}.updateHttpTimeout.errors.invalidTimeout`, {
                timeout,
                minTimeout: config_1.MIN_HTTP_TIMEOUT,
            }));
        }
        this.config.httpTimeout = parsedTimeout;
        return this.write();
    }
    /**
     * @throws {Error}
     */
    updateAllowUsageTracking(isEnabled) {
        if (!this.config) {
            throw new Error((0, lang_1.i18n)(`${i18nKey}.errors.noConfigLoaded`));
        }
        if (typeof isEnabled !== 'boolean') {
            throw new Error((0, lang_1.i18n)(`${i18nKey}.updateAllowUsageTracking.errors.invalidInput`, {
                isEnabled: `${isEnabled}`,
            }));
        }
        this.config.allowUsageTracking = isEnabled;
        return this.write();
    }
    isTrackingAllowed() {
        if (!this.config) {
            return true;
        }
        return this.config.allowUsageTracking !== false;
    }
}
exports.CLIConfiguration = new _CLIConfiguration();
