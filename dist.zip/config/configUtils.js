"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.generateConfig = exports.getOrderedConfig = exports.getOrderedAccount = void 0;
const logger_1 = require("../lib/logger");
const auth_1 = require("../constants/auth");
const lang_1 = require("../utils/lang");
const i18nKey = 'config.configUtils';
function getOrderedAccount(unorderedAccount) {
    const { name, accountId, env, authType, ...rest } = unorderedAccount;
    return {
        name,
        accountId,
        env,
        authType,
        ...rest,
    };
}
exports.getOrderedAccount = getOrderedAccount;
function getOrderedConfig(unorderedConfig) {
    const { defaultAccount, defaultMode, httpTimeout, allowUsageTracking, accounts, ...rest } = unorderedConfig;
    return {
        ...(defaultAccount && { defaultAccount }),
        defaultMode,
        httpTimeout,
        allowUsageTracking,
        ...rest,
        accounts: accounts.map(getOrderedAccount),
    };
}
exports.getOrderedConfig = getOrderedConfig;
function generatePersonalAccessKeyAccountConfig({ accountId, personalAccessKey, env, }) {
    return {
        authType: auth_1.PERSONAL_ACCESS_KEY_AUTH_METHOD.value,
        accountId,
        personalAccessKey,
        env,
    };
}
function generateOauthAccountConfig({ accountId, clientId, clientSecret, refreshToken, scopes, env, }) {
    return {
        authType: auth_1.OAUTH_AUTH_METHOD.value,
        accountId,
        auth: {
            clientId,
            clientSecret,
            scopes,
            tokenInfo: {
                refreshToken,
            },
        },
        env,
    };
}
function generateApiKeyAccountConfig({ accountId, apiKey, env, }) {
    return {
        authType: auth_1.API_KEY_AUTH_METHOD.value,
        accountId,
        apiKey,
        env,
    };
}
function generateConfig(type, options) {
    if (!options) {
        return null;
    }
    const config = { accounts: [] };
    let configAccount;
    switch (type) {
        case auth_1.API_KEY_AUTH_METHOD.value:
            configAccount = generateApiKeyAccountConfig(options);
            break;
        case auth_1.PERSONAL_ACCESS_KEY_AUTH_METHOD.value:
            configAccount = generatePersonalAccessKeyAccountConfig(options);
            break;
        case auth_1.OAUTH_AUTH_METHOD.value:
            configAccount = generateOauthAccountConfig(options);
            break;
        default:
            logger_1.logger.debug((0, lang_1.i18n)(`${i18nKey}.unknownType`, { type }));
            return null;
    }
    if (configAccount) {
        config.accounts.push(configAccount);
    }
    return config;
}
exports.generateConfig = generateConfig;
