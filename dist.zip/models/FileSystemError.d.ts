import { FileSystemErrorContext } from '../types/Error';
export declare class FileSystemError extends Error {
    private context;
    constructor(options?: ErrorOptions, context?: FileSystemErrorContext);
    toString(): string;
}
