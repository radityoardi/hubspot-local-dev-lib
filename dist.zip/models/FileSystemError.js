"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.FileSystemError = void 0;
const lang_1 = require("../utils/lang");
const errors_1 = require("../errors");
const i18nKey = 'errors.fileSystemErrors';
class FileSystemError extends Error {
    context;
    constructor(options, context) {
        super('', options);
        this.name = 'FileSystemError';
        this.context = context;
        if (context) {
            let fileAction = '';
            if (context.operation === 'read') {
                fileAction = (0, lang_1.i18n)(`${i18nKey}.readAction`);
            }
            else if (context.operation === 'write') {
                fileAction = (0, lang_1.i18n)(`${i18nKey}.writeAction`);
            }
            else {
                fileAction = (0, lang_1.i18n)(`${i18nKey}.otherAction`);
            }
            const filepath = context.filepath
                ? `"${context.filepath}"`
                : (0, lang_1.i18n)(`${i18nKey}.unknownFilepath`);
            const messages = [
                (0, lang_1.i18n)(`${i18nKey}.baseMessage`, { fileAction, filepath }),
            ];
            // Many `fs` errors will be `SystemError`s
            if ((0, errors_1.isSystemError)(options?.cause)) {
                messages.push((0, lang_1.i18n)(`${i18nKey}.baseMessage`, {
                    errorMessage: options?.cause?.message || '',
                }));
            }
            this.message = messages.join(' ');
        }
    }
    toString() {
        let baseString = `${this.name}: ${this.message}`;
        if (this.context) {
            baseString = `${baseString} context: ${this.context}`;
        }
        return baseString;
    }
}
exports.FileSystemError = FileSystemError;
