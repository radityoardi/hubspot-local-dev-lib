import { HubSpotHttpErrorContext } from '../types/Error';
export declare class HubSpotHttpError<T = any> extends Error {
    status?: number;
    code?: string;
    statusText?: string;
    data?: T;
    headers?: {
        [key: string]: unknown;
    };
    method: string | undefined;
    context: HubSpotHttpErrorContext | undefined;
    derivedContext: HubSpotHttpErrorContext | undefined;
    validationErrors: string[] | undefined;
    detailedMessage?: string;
    private divider;
    cause: ErrorOptions['cause'];
    constructor(message?: string, options?: ErrorOptions, context?: HubSpotHttpErrorContext);
    updateContext(context: Partial<HubSpotHttpErrorContext>): void;
    toString(): string;
    formattedValidationErrors(): string;
    private extractDerivedContext;
    private parseValidationErrors;
    private joinErrorMessages;
}
