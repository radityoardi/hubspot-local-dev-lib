"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.OAuth2Manager = void 0;
const axios_1 = __importDefault(require("axios"));
const moment_1 = __importDefault(require("moment"));
const urls_1 = require("../lib/urls");
const environment_1 = require("../lib/environment");
const logger_1 = require("../lib/logger");
const getAccountIdentifier_1 = require("../utils/getAccountIdentifier");
const auth_1 = require("../constants/auth");
const lang_1 = require("../utils/lang");
const i18nKey = 'models.OAuth2Manager';
class OAuth2Manager {
    account;
    writeTokenInfo;
    refreshTokenRequest;
    constructor(account, writeTokenInfo) {
        this.writeTokenInfo = writeTokenInfo;
        this.refreshTokenRequest = null;
        this.account = account;
        if (this.account.env) {
            this.account.env = (0, environment_1.getValidEnv)(this.account.env, '');
        }
    }
    async accessToken() {
        if (!this.account.tokenInfo?.refreshToken) {
            throw new Error((0, lang_1.i18n)(`${i18nKey}.errors.missingRefreshToken`, {
                accountId: (0, getAccountIdentifier_1.getAccountIdentifier)(this.account),
            }));
        }
        if (!this.account.tokenInfo?.accessToken ||
            (0, moment_1.default)()
                .add(5, 'minutes')
                .isAfter((0, moment_1.default)(new Date(this.account.tokenInfo.expiresAt || '')))) {
            await this.refreshAccessToken();
        }
        return this.account.tokenInfo.accessToken;
    }
    async fetchAccessToken(exchangeProof) {
        logger_1.logger.debug((0, lang_1.i18n)(`${i18nKey}.fetchingAccessToken`, {
            accountId: (0, getAccountIdentifier_1.getAccountIdentifier)(this.account),
            clientId: this.account.clientId || '',
        }));
        try {
            const { data } = await (0, axios_1.default)({
                url: `${(0, urls_1.getHubSpotApiOrigin)((0, environment_1.getValidEnv)(this.account.env))}/oauth/v1/token`,
                method: 'post',
                data: exchangeProof,
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            });
            this.refreshTokenRequest = data;
            const { refresh_token: refreshToken, access_token: accessToken, expires_in: expiresIn, } = data;
            if (!this.account.tokenInfo) {
                this.account.tokenInfo = {};
            }
            this.account.tokenInfo.refreshToken = refreshToken;
            this.account.tokenInfo.accessToken = accessToken;
            this.account.tokenInfo.expiresAt = (0, moment_1.default)()
                .add(Math.round(parseInt(expiresIn) * 0.75), 'seconds')
                .toString();
            if (this.writeTokenInfo) {
                logger_1.logger.debug((0, lang_1.i18n)(`${i18nKey}.updatingTokenInfo`, {
                    accountId: (0, getAccountIdentifier_1.getAccountIdentifier)(this.account),
                    clientId: this.account.clientId || '',
                }));
                this.writeTokenInfo(this.account.tokenInfo);
            }
        }
        finally {
            this.refreshTokenRequest = null;
        }
    }
    async exchangeForTokens(exchangeProof) {
        if (this.refreshTokenRequest) {
            logger_1.logger.debug((0, lang_1.i18n)(`${i18nKey}.refreshingAccessToken`, {
                accountId: (0, getAccountIdentifier_1.getAccountIdentifier)(this.account),
                clientId: this.account.clientId || '',
            }));
            await this.refreshTokenRequest;
        }
        else {
            await this.fetchAccessToken(exchangeProof);
        }
    }
    async refreshAccessToken() {
        const refreshTokenProof = {
            grant_type: 'refresh_token',
            client_id: this.account.clientId,
            client_secret: this.account.clientSecret,
            refresh_token: this.account.tokenInfo?.refreshToken,
        };
        await this.exchangeForTokens(refreshTokenProof);
    }
    static fromConfig(accountConfig, writeTokenInfo) {
        return new OAuth2Manager({
            ...accountConfig,
            authType: auth_1.AUTH_METHODS.oauth.value,
            ...(accountConfig.auth || {}),
        }, writeTokenInfo);
    }
}
exports.OAuth2Manager = OAuth2Manager;
