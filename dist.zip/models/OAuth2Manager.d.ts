import { FlatAccountFields, OAuth2ManagerAccountConfig, WriteTokenInfoFunction, RefreshTokenResponse, ExchangeProof } from '../types/Accounts';
export declare class OAuth2Manager {
    account: OAuth2ManagerAccountConfig;
    writeTokenInfo?: WriteTokenInfoFunction;
    refreshTokenRequest: Promise<RefreshTokenResponse> | null;
    constructor(account: OAuth2ManagerAccountConfig, writeTokenInfo?: WriteTokenInfoFunction);
    accessToken(): Promise<string | undefined>;
    fetchAccessToken(exchangeProof: ExchangeProof): Promise<void>;
    exchangeForTokens(exchangeProof: ExchangeProof): Promise<void>;
    refreshAccessToken(): Promise<void>;
    static fromConfig(accountConfig: FlatAccountFields, writeTokenInfo: WriteTokenInfoFunction): OAuth2Manager;
}
