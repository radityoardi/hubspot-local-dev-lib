import { AxiosPromise } from 'axios';
import { HttpOptions } from '../types/Http';
export declare function addUserAgentHeader(key: string, value: string): void;
declare function getRequest<T>(accountId: number, options: HttpOptions): AxiosPromise<T>;
declare function postRequest<T>(accountId: number, options: HttpOptions): AxiosPromise<T>;
declare function putRequest<T>(accountId: number, options: HttpOptions): AxiosPromise<T>;
declare function patchRequest<T>(accountId: number, options: HttpOptions): AxiosPromise<T>;
declare function deleteRequest<T>(accountId: number, options: HttpOptions): AxiosPromise<T>;
export declare const http: {
    get: typeof getRequest;
    post: typeof postRequest;
    put: typeof putRequest;
    patch: typeof patchRequest;
    delete: typeof deleteRequest;
    getOctetStream: (accountId: number, options: HttpOptions, destPath: string) => AxiosPromise<any>;
};
export {};
