"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.http = void 0;
const axios_1 = __importDefault(require("axios"));
const getAxiosConfig_1 = require("./getAxiosConfig");
const addQueryParams_1 = require("./addQueryParams");
async function getRequest(options) {
    const { params, ...rest } = options;
    const optionsWithParams = (0, addQueryParams_1.addQueryParams)(rest, params);
    const requestConfig = await (0, getAxiosConfig_1.getAxiosConfig)(optionsWithParams);
    return (0, axios_1.default)(requestConfig);
}
async function postRequest(options) {
    const requestConfig = await (0, getAxiosConfig_1.getAxiosConfig)(options);
    return (0, axios_1.default)({ ...requestConfig, method: 'post' });
}
async function putRequest(options) {
    const requestConfig = await (0, getAxiosConfig_1.getAxiosConfig)(options);
    return (0, axios_1.default)({ ...requestConfig, method: 'put' });
}
async function patchRequest(options) {
    const requestConfig = await (0, getAxiosConfig_1.getAxiosConfig)(options);
    return (0, axios_1.default)({ ...requestConfig, method: 'patch' });
}
async function deleteRequest(options) {
    const requestConfig = await (0, getAxiosConfig_1.getAxiosConfig)(options);
    return (0, axios_1.default)({ ...requestConfig, method: 'delete' });
}
exports.http = {
    get: getRequest,
    post: postRequest,
    put: putRequest,
    patch: patchRequest,
    delete: deleteRequest,
};
