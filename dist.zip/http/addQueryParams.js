"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.addQueryParams = void 0;
function addQueryParams(configOptions, queryParams = {}) {
    const { params } = configOptions;
    return {
        ...configOptions,
        params: {
            ...queryParams,
            ...params,
        },
    };
}
exports.addQueryParams = addQueryParams;
