import { AxiosPromise } from 'axios';
import { HttpOptions } from '../types/Http';
declare function getRequest<T>(options: HttpOptions): AxiosPromise<T>;
declare function postRequest<T>(options: HttpOptions): AxiosPromise<T>;
declare function putRequest<T>(options: HttpOptions): AxiosPromise<T>;
declare function patchRequest<T>(options: HttpOptions): AxiosPromise<T>;
declare function deleteRequest<T>(options: HttpOptions): AxiosPromise<T>;
export declare const http: {
    get: typeof getRequest;
    post: typeof postRequest;
    put: typeof putRequest;
    patch: typeof patchRequest;
    delete: typeof deleteRequest;
};
export {};
