import { HttpOptions, QueryParams } from '../types/Http';
export declare function addQueryParams(configOptions: HttpOptions, queryParams?: QueryParams): HttpOptions;
