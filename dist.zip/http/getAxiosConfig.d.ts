import { HttpOptions } from '../types/Http';
import { AxiosRequestConfig } from 'axios';
export declare const USER_AGENTS: {
    [key: string]: string;
};
export declare function getDefaultUserAgentHeader(): {
    'User-Agent': string;
};
export declare function getAxiosConfig(options: HttpOptions): AxiosRequestConfig;
