"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.getAxiosConfig = exports.getDefaultUserAgentHeader = exports.USER_AGENTS = void 0;
const package_json_1 = require("../package.json");
const config_1 = require("../config");
const urls_1 = require("../lib/urls");
const https_1 = __importDefault(require("https"));
const http_1 = __importDefault(require("http"));
// Total number of sockets across all hosts
const MAX_TOTAL_SOCKETS = 25;
// Total number of sockets per each host
const MAX_SOCKETS_PER_HOST = 5;
const httpAgent = new http_1.default.Agent({
    keepAlive: true,
    maxTotalSockets: MAX_TOTAL_SOCKETS,
    maxSockets: MAX_SOCKETS_PER_HOST,
});
const httpsAgent = new https_1.default.Agent({
    keepAlive: true,
    maxTotalSockets: MAX_TOTAL_SOCKETS,
    maxSockets: MAX_SOCKETS_PER_HOST,
});
exports.USER_AGENTS = {
    'HubSpot Local Dev Lib': package_json_1.version,
};
function getDefaultUserAgentHeader() {
    let userAgentString = '';
    Object.keys(exports.USER_AGENTS).forEach((userAgentKey, i) => {
        userAgentString += `${i > 0 ? ', ' : ''}${userAgentKey}/${exports.USER_AGENTS[userAgentKey]}`;
    });
    return {
        'User-Agent': userAgentString,
    };
}
exports.getDefaultUserAgentHeader = getDefaultUserAgentHeader;
const DEFAULT_TRANSITIONAL = {
    clarifyTimeoutError: true,
};
function getAxiosConfig(options) {
    const { env, localHostOverride, headers, ...rest } = options;
    const config = (0, config_1.getAndLoadConfigIfNeeded)();
    let httpTimeout = 15000;
    let httpUseLocalhost = false;
    if (config && config.httpTimeout) {
        httpTimeout = config.httpTimeout;
    }
    if (config && config.httpUseLocalhost) {
        httpUseLocalhost = config.httpUseLocalhost;
    }
    return {
        baseURL: (0, urls_1.getHubSpotApiOrigin)(env, localHostOverride ? false : httpUseLocalhost),
        headers: {
            ...getDefaultUserAgentHeader(),
            ...(headers || {}),
        },
        timeout: httpTimeout,
        transitional: DEFAULT_TRANSITIONAL,
        httpAgent,
        httpsAgent,
        ...rest,
    };
}
exports.getAxiosConfig = getAxiosConfig;
