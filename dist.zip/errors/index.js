"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.isFileSystemError = exports.isSystemError = exports.isHubSpotHttpError = exports.isValidationError = exports.isAuthError = exports.isTimeoutError = exports.isGatingError = exports.isMissingScopeError = exports.isSpecifiedError = void 0;
const HubSpotHttpError_1 = require("../models/HubSpotHttpError");
const FileSystemError_1 = require("../models/FileSystemError");
function isSpecifiedError(err, { statusCode, category, subCategory, errorType, code, }) {
    if (!isHubSpotHttpError(err)) {
        return false;
    }
    const { data, status, code: actualCode } = err;
    const statusCodeMatchesError = !statusCode || status === statusCode;
    const categoryMatchesError = !category || data?.category === category;
    const subCategoryMatchesError = !subCategory || data?.subCategory === subCategory;
    const errorTypeMatchesError = !errorType || data?.errorType === errorType;
    const codeMatchesError = !code || actualCode === code;
    return (statusCodeMatchesError &&
        categoryMatchesError &&
        subCategoryMatchesError &&
        errorTypeMatchesError &&
        codeMatchesError);
}
exports.isSpecifiedError = isSpecifiedError;
function isMissingScopeError(err) {
    return isSpecifiedError(err, { statusCode: 403, category: 'MISSING_SCOPES' });
}
exports.isMissingScopeError = isMissingScopeError;
function isGatingError(err) {
    return isSpecifiedError(err, { statusCode: 403, category: 'GATED' });
}
exports.isGatingError = isGatingError;
function isTimeoutError(err) {
    return isSpecifiedError(err, { code: 'ETIMEDOUT' });
}
exports.isTimeoutError = isTimeoutError;
function isAuthError(err) {
    return (isSpecifiedError(err, { statusCode: 401 }) ||
        isSpecifiedError(err, { statusCode: 403 }));
}
exports.isAuthError = isAuthError;
function isValidationError(err) {
    return (isHubSpotHttpError(err) &&
        isSpecifiedError(err, { statusCode: 400 }) &&
        !!(err?.data?.message || !!err.data?.errors));
}
exports.isValidationError = isValidationError;
function isHubSpotHttpError(error) {
    return !!error && error instanceof HubSpotHttpError_1.HubSpotHttpError;
}
exports.isHubSpotHttpError = isHubSpotHttpError;
function isSystemError(err) {
    return (err instanceof Error &&
        'errno' in err &&
        err.errno != null &&
        'code' in err &&
        err.code != null &&
        'syscall' in err &&
        err.syscall != null);
}
exports.isSystemError = isSystemError;
function isFileSystemError(err) {
    return err instanceof FileSystemError_1.FileSystemError;
}
exports.isFileSystemError = isFileSystemError;
