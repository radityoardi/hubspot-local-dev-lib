import { BaseError, FileSystemErrorContext, ErrorContext } from '../types/Error';
export declare function logErrorInstance(error: BaseError, context?: ErrorContext): void;
export declare function logFileSystemErrorInstance(error: BaseError, context: FileSystemErrorContext): void;
