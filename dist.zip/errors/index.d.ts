import { HubSpotHttpError } from '../models/HubSpotHttpError';
import { BaseError } from '../types/Error';
import { FileSystemError } from '../models/FileSystemError';
export declare function isSpecifiedError(err: unknown, { statusCode, category, subCategory, errorType, code, }: {
    statusCode?: number;
    category?: string;
    subCategory?: string;
    errorType?: string;
    code?: string;
}): err is HubSpotHttpError;
export declare function isMissingScopeError(err: unknown): err is HubSpotHttpError;
export declare function isGatingError(err: unknown): err is HubSpotHttpError;
export declare function isTimeoutError(err: unknown): err is HubSpotHttpError;
export declare function isAuthError(err: unknown): err is HubSpotHttpError;
export declare function isValidationError(err: unknown): boolean;
export declare function isHubSpotHttpError(error?: unknown): error is HubSpotHttpError;
export declare function isSystemError(err: unknown): err is BaseError;
export declare function isFileSystemError(err: unknown): err is FileSystemError;
